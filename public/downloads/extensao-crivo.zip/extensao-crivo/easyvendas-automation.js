// easyvendas-automation.js
// -----------------------------------------------------------------------
// Lógica da automação, separada dos seletores (easyvendas-selectors.js) e
// da orquestração (easyvendas.js) — mesmo princípio do projeto P2B (veja
// P2BAutomation.js): nunca uma função só "clica e fica esperando". Cada
// método aqui é uma ação curta sobre o estado ATUAL da tela. Quem decide
// o que fazer a seguir é o laço em easyvendas.js, chamando detectarEstado()
// a cada rodada — exatamente como uma pessoa faria: olha a tela agora,
// entende o que tem ali, só depois age.
//
// Como a extensão sabe se apareceu uma mensagem de resultado: em vez de
// procurar um título/modal específico (que muda de tela pra tela e já deu
// bug — veja o histórico de commits), ela tira uma "foto" do texto da tela
// ANTES de clicar, e depois de clicar compara com o texto ATUAL: qualquer
// linha nova que aparecer é candidata a mensagem de resultado. Isso evita
// confundir com texto que já tava lá antes (tipo "TIM, líder em cobertura"
// no rodapé) e funciona em qualquer sistema, não importa o layout.
// -----------------------------------------------------------------------

// Mesma correção de easyvendas.js — acorda na hora assim que a aba fica
// visível de novo, em vez de esperar o temporizador (desacelerado pelo
// Chrome enquanto a aba ficava em segundo plano) terminar sozinho.
function dormir(ms) {
  return new Promise((resolve) => {
    let concluido = false
    const concluir = () => {
      if (concluido) return
      concluido = true
      clearTimeout(temporizador)
      document.removeEventListener('visibilitychange', aoFicarVisivel)
      resolve()
    }
    const temporizador = setTimeout(concluir, ms)
    function aoFicarVisivel() {
      if (document.visibilityState === 'visible') concluir()
    }
    document.addEventListener('visibilitychange', aoFicarVisivel)
  })
}

// Atraso aleatório dentro de uma faixa — usado pra espaçar os passos da
// automação (digitar, pausar antes de clicar) num ritmo parecido com o de
// uma pessoa, em vez de tudo acontecendo instantaneamente.
function pausaHumana(minMs, maxMs) {
  return dormir(minMs + Math.random() * (maxMs - minMs))
}

function semAcento(txt) {
  return (txt || '')
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
}

function linhasDoBody() {
  return (document.body.innerText || '').split('\n').map((l) => l.trim()).filter(Boolean)
}

class EasyVendasAutomation {
  constructor(selectors) {
    this.selectors = selectors
  }

  acharCampoCnpj() {
    const porSeletor = document.querySelector(this.selectors.campoCnpjSeletor)
    if (porSeletor) return porSeletor

    // Fallback: procura pelo texto "cnpj" no rótulo/contêiner ao redor do
    // input, subindo até 4 níveis na árvore (cobre rótulo que fica alguns
    // níveis acima do campo, com outros elementos no meio).
    const alvo = this.selectors.campoCnpjContainerTexto
    const inputs = [...document.querySelectorAll('input')]
    for (const input of inputs) {
      const atributos = semAcento(
        [input.placeholder, input.getAttribute('aria-label'), input.name, input.id].filter(Boolean).join(' ')
      )
      if (atributos.includes(alvo)) return input

      let container = input.parentElement
      for (let nivel = 0; container && nivel < 4; nivel++, container = container.parentElement) {
        if (semAcento(container.textContent || '').includes(alvo)) return input
      }
    }
    return null
  }

  // Acha, dentro de um container qualquer (pode ser o document inteiro),
  // um botão cujo texto OU aria-label CONTENHA um dos alvos (sem acento/
  // maiúscula) — alguns botões (ex: "Clientes" no menu) não têm texto
  // visível, só aria-label. Não exige igualdade exata porque o botão às
  // vezes tem um ícone junto que entra no texto — fica com o elemento de
  // texto MAIS CURTO entre os que batem, pra não pegar um contêiner
  // grande por cima do botão.
  acharBotaoDentro(container, alvos) {
    const normalizados = alvos.map((a) => semAcento(a).trim())
    const elementos = [...container.querySelectorAll('button, [role="button"], a')]
    let melhor = null
    for (const el of elementos) {
      const texto = semAcento(`${el.textContent || ''} ${el.getAttribute('aria-label') || ''}`).trim()
      if (!texto) continue
      const bate = normalizados.some((alvo) => texto.includes(alvo))
      if (!bate) continue
      if (!melhor || texto.length < melhor.texto.length) melhor = { el, texto }
    }
    return melhor?.el || null
  }

  acharBotaoPorTexto(alvos) {
    return this.acharBotaoDentro(document, alvos)
  }

  // Mesma busca de botão, mas só perto de um campo (sobe até 6 níveis na
  // árvore) — usado quando tem MAIS de um botão igual na tela (ex: duas
  // lupas de busca, uma do CNPJ e outra do CEP) e precisa achar a certa.
  acharBotaoPertoDe(elemento, alvos) {
    let container = elemento.parentElement
    for (let nivel = 0; container && nivel < 6; nivel++, container = container.parentElement) {
      const achado = this.acharBotaoDentro(container, alvos)
      if (achado) return achado
    }
    return null
  }

  listarBotoesVisiveis(limite = 20) {
    return [...document.querySelectorAll('button, [role="button"], a')]
      .map((el) => (el.textContent || '').trim())
      .filter(Boolean)
      .slice(0, limite)
  }

  // Campos do formulário que o Angular marca como inválidos agora —
  // ajuda a explicar quando um clique em "Solicitar"/"Avançar" não faz
  // nada visível (pode ser o formulário bloqueado por um campo
  // obrigatório vazio, tipo Contato/Telefone, que a busca de CNPJ não
  // preenche sozinha).
  camposInvalidosVisiveis(limite = 10) {
    return [...document.querySelectorAll('.ng-invalid, [aria-invalid="true"]')]
      .filter((el) => el.tagName === 'INPUT' || el.tagName === 'SELECT' || el.tagName === 'TEXTAREA')
      .map((el) => {
        const container = el.closest('div, label, section')
        const rotulo = container?.querySelector('label')?.textContent?.trim()
        return rotulo || el.getAttribute('aria-label') || el.name || el.id || el.tagName
      })
      .filter(Boolean)
      .slice(0, limite)
  }

  definirValorInput(input, valor) {
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set
    setter.call(input, valor)
    input.dispatchEvent(new Event('input', { bubbles: true }))
    input.dispatchEvent(new Event('change', { bubbles: true }))
    input.dispatchEvent(new Event('blur', { bubbles: true }))
  }

  formatarCnpj(digitos) {
    return digitos.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5')
  }

  // Foto do texto da tela agora — guarda antes de clicar, pra comparar
  // depois e achar só o que é NOVO (veja textoNovoDesde).
  tirarFotoTexto() {
    return new Set(linhasDoBody())
  }

  // Linhas que estão na tela AGORA mas não estavam na foto tirada antes.
  // Ignora linhas que são só "CNPJ: ..." — isso aparece na tela ANTES do
  // resultado de verdade (a empresa carregando), nunca é o resultado em
  // si, e já vimos ele fazer a extensão "travar" achando que já tinha
  // terminado (leu só isso e classificou errado como aprovado).
  textoNovoDesde(fotoAntes) {
    return linhasDoBody()
      .filter((l) => !fotoAntes.has(l))
      .filter((l) => !/^cnpj:?\s*[\d.\-/]+$/i.test(l.trim()))
      .join(' ')
      .trim()
  }

  // Descreve a tela ATUAL sem clicar em nada. Chamado a cada rodada do
  // laço em easyvendas.js — é o "olhar pra tela" antes de decidir agir.
  detectarEstado() {
    const campoCnpj = this.acharCampoCnpj()

    // Às vezes (visto ao vivo no 1º sistema) o campo de CNPJ fica cinza e
    // trancado — não some da tela, só não aceita mais digitação. Se
    // tratasse isso como "formulario" normal (campo + botão achados), a
    // extensão ia tentar digitar num campo travado e nada acontecia,
    // travando a fila inteira sem avisar nada de errado. Detecta esse
    // estado ANTES de considerar formulário normal, pra quem chama saber
    // que precisa recuperar a tela (clicar Clientes > Adicionar) em vez
    // de tentar digitar.
    if (campoCnpj && (campoCnpj.disabled || campoCnpj.readOnly || campoCnpj.getAttribute('aria-disabled') === 'true')) {
      return { tipo: 'travado', campoCnpj }
    }

    const botaoAvancar = this.acharBotaoPorTexto(this.selectors.botaoAvancarTextos)
    if (campoCnpj && botaoAvancar) return { tipo: 'formulario', campoCnpj, botaoAvancar }

    return {
      tipo: 'desconhecido',
      url: location.href,
      botoesVisiveis: this.listarBotoesVisiveis(),
    }
  }

  // Dispara os eventos de teclado de UM caractere (keydown/keypress/input/
  // keyup) e já deixa o valor do campo crescido até esse ponto — simula o
  // que o navegador faria a cada tecla apertada de verdade, pra qualquer
  // listener da página (validação, máscara etc.) reagir igual reagiria a
  // alguém digitando.
  digitarUmCaractere(input, caractere, valorAteAgora) {
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set
    input.dispatchEvent(new KeyboardEvent('keydown', { key: caractere, bubbles: true }))
    input.dispatchEvent(new KeyboardEvent('keypress', { key: caractere, bubbles: true }))
    setter.call(input, valorAteAgora)
    input.dispatchEvent(new Event('input', { bubbles: true }))
    input.dispatchEvent(new KeyboardEvent('keyup', { key: caractere, bubbles: true }))
  }

  // Digita o CNPJ devagar, caractere por caractere, com uma pausa curta e
  // ligeiramente aleatória entre cada um — em vez de colar o valor inteiro
  // de uma vez (era assim antes: `definirValorInput` direto). Só digita,
  // sem clicar em nada — usado quando o clique é um passo separado (veja
  // acharBotaoBuscar, pro sistema 1).
  async digitarCnpj(campoCnpj, cnpjDigitos) {
    campoCnpj.focus()
    this.definirValorInput(campoCnpj, '')
    const textoFormatado = this.formatarCnpj(cnpjDigitos)
    let valorAteAgora = ''
    for (const caractere of textoFormatado) {
      valorAteAgora += caractere
      this.digitarUmCaractere(campoCnpj, caractere, valorAteAgora)
      await pausaHumana(50, 130)
    }
    campoCnpj.dispatchEvent(new Event('change', { bubbles: true }))
    campoCnpj.dispatchEvent(new Event('blur', { bubbles: true }))
  }

  // Preenche o CNPJ e clica no botão de consultar, num passo só — usado
  // quando não tem uma busca separada antes (sistema 2). Ação que PODE
  // navegar a tela — por isso não fica esperando resposta aqui dentro;
  // quem confirma o que aconteceu é a próxima rodada do laço, comparando
  // o texto da tela com a foto tirada antes (veja textoNovoDesde).
  async preencherEAvancar(estadoFormulario, cnpjDigitos) {
    await this.digitarCnpj(estadoFormulario.campoCnpj, cnpjDigitos)
    await pausaHumana(300, 600) // pausa antes de clicar, igual alguém conferindo o que digitou
    estadoFormulario.botaoAvancar.click()
  }

  // Lupa de busca ao lado do CNPJ (só sistema 1) — busca/carrega os dados
  // da empresa antes do Solicitar. Devolve null se não achar (aí segue
  // direto pro botão de consultar, como antes).
  acharBotaoBuscar() {
    return this.acharBotaoPorTexto(this.selectors.botaoBuscarTextos)
  }

  // Campo de CEP (só existe na tela "Adicionar Clientes", sistema 1) —
  // confirmado no HTML real: <input name="cep" md-cep-input ...>.
  acharCampoCep() {
    return document.querySelector(this.selectors.campoCepSeletor)
  }

  // Lupa de busca do CEP — tem o MESMO texto ("search") da lupa do CNPJ,
  // por isso busca perto do próprio campo de CEP, não em qualquer lugar
  // da tela (senão podia clicar a lupa errada).
  acharBotaoBuscarCep(campoCep) {
    return this.acharBotaoPertoDe(campoCep, this.selectors.botaoBuscarTextos)
  }

  // Volta pra tela de "Adicionar Clientes" clicando Clientes > Adicionar
  // — usado quando a extensão recarrega a página e cai numa tela
  // diferente (não direto no formulário com o campo CNPJ). Devolve true
  // se clicou em algum dos dois (a próxima rodada do laço confere se já
  // chegou no formulário).
  async navegarParaAdicionarClientes() {
    const botaoAdicionarJaVisivel = this.acharBotaoPorTexto(this.selectors.botaoAdicionarTextos)
    if (botaoAdicionarJaVisivel) {
      await pausaHumana(250, 600)
      botaoAdicionarJaVisivel.click()
      return true
    }

    const botaoClientes = this.acharBotaoPorTexto(this.selectors.botaoClientesTextos)
    if (!botaoClientes) return false

    await pausaHumana(250, 600)
    botaoClientes.click()

    // A página demora um pouco pra carregar depois de clicar em
    // "Clientes" — antes a extensão só tentava achar "Adicionar" de novo
    // na PRÓXIMA rodada do laço (1,5s depois, só uma vez), o que podia
    // não ser tempo suficiente e fazia parecer que travou. Agora espera
    // de verdade o botão "Adicionar" aparecer, checando a cada 300ms até
    // 6s, e só desiste se ele não aparecer nesse tempo todo.
    const inicio = Date.now()
    while (Date.now() - inicio < 6000) {
      await dormir(300)
      const botaoAdicionar = this.acharBotaoPorTexto(this.selectors.botaoAdicionarTextos)
      if (botaoAdicionar) {
        await pausaHumana(250, 600)
        botaoAdicionar.click()
        return true
      }
    }
    return true // já clicou em "Clientes" pelo menos — próxima rodada confere o resultado
  }

  // Tela de Contrato (Termo de Contratação / Contrato de Permanência) —
  // detecta pelo texto do cabeçalho/abas. A extensão NUNCA clica em nada
  // aqui (nem Salvar, nem Enviar por e-mail, nem Cancelar) — só serve pra
  // saber que caiu nela sem querer e precisa voltar (veja
  // voltarUmaPagina), sem tentar ler nem decidir nada nessa tela.
  pareceTelaDeContrato() {
    return this.selectors.padraoTelaContrato.test(semAcento(document.body.innerText || ''))
  }

  // Volta uma página no histórico do navegador — igual clicar no botão
  // "voltar" — usado quando cai na tela de Contrato sem querer, pra
  // voltar pra tela anterior e esperar a mensagem de resultado de
  // verdade aparecer ali.
  voltarUmaPagina() {
    history.back()
  }

  ehNaoEncontrado(mensagem) {
    return this.selectors.padraoNaoEncontrado.test(semAcento(mensagem))
  }

  // "Formulário com pendências" — erro, não resultado (veja o comentário
  // no seletor). Quem chama isso trata como erro e manda tentar de novo,
  // nunca grava como aprovado/reprovado.
  ehSessaoEncerrada(mensagem) {
    return this.selectors.padraoSessaoEncerrada.test(semAcento(mensagem))
  }

  // A aba caiu na tela de login (sessão encerrada ou expirada).
  estaNaTelaDeLogin() {
    return location.href.includes(this.selectors.urlTelaLogin)
  }

  ehFormularioIncompleto(mensagem) {
    return this.selectors.padraoFormularioIncompleto.test(semAcento(mensagem))
  }

  // Empresa aberta há menos de 6 meses — frase direta, ou "aberta/
  // constituída/fundada há N meses" com N < 6 (número checado em código).
  empresaMuitoRecente(normalizado) {
    if (this.selectors.padraoEmpresaRecenteDireto.test(normalizado)) return true
    const m = normalizado.match(this.selectors.padraoEmpresaRecenteComNumero)
    return m ? Number(m[2]) < 6 : false
  }

  // numeroSistema decide qual regra de reprovação vale (são diferentes em
  // cada sistema — veja easyvendas-selectors.js):
  // - sistema 1 (Crivo 1, interno TIM): só reprova com dívida Tim, cheque
  //   sem fundo ou empresa recém-aberta. Restrição de CNPJ/sócio sozinha
  //   NÃO reprova aqui.
  // - sistema 2 (Crivo 2, crivo de mercado — pesa mais): reprova com
  //   retaguarda/negado/inadimplente OU restrição de mercado.
  // ANTES disso: se a mensagem disser "negado"/"retaguarda" explicitamente,
  // ou citar dívida financeira com a Tim, já é reprovado na hora nos dois
  // sistemas, não importa o motivo escrito depois (motivo pode ser
  // qualquer coisa, ex: "Valor em desacordo com o porte" — que não bate
  // com nenhuma regra específica abaixo).
  // Fora isso tudo, é aprovado.
  classificarMensagem(mensagem, numeroSistema) {
    const normalizado = semAcento(mensagem)

    if (this.selectors.padraoNegadoExplicito.test(normalizado)) return 'reprovado'
    if (this.selectors.padraoDividaTim.test(normalizado)) return 'reprovado'

    if (numeroSistema === 1) {
      const reprovado =
        this.selectors.sistema1PadraoReprovado.test(normalizado) ||
        this.selectors.padraoChequeSemFundo.test(normalizado) ||
        this.empresaMuitoRecente(normalizado)
      if (reprovado) return 'reprovado'
      return this.selectors.padraoRespostaDeCredito.test(normalizado) ? 'aprovado' : 'nao_reconhecido'
    }

    const reprovado =
      this.selectors.sistema2PadraoReprovado.test(normalizado) ||
      this.selectors.padraoRestricaoMercado.test(normalizado)
    if (reprovado) return 'reprovado'
    // Não é reprovação nem resposta de crédito reconhecida: quem chama
    // trata como erro (tenta de novo e, se continuar, pede conferência
    // manual). Nunca vira aprovado por padrão.
    return this.selectors.padraoRespostaDeCredito.test(normalizado) ? 'aprovado' : 'nao_reconhecido'
  }

  // Fecha uma janela de resultado deixada aberta de uma consulta anterior
  // (limpeza antes de começar uma nova) — não faz nada se não achar.
  fecharModal() {
    const botaoOk = this.acharBotaoPorTexto(this.selectors.botaoOkTextos)
    if (botaoOk) botaoOk.click()
    return Boolean(botaoOk)
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { EasyVendasAutomation }
}
