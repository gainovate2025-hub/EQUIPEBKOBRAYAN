// 1.5.2: nenhuma falha solta (promessa sem tratamento) vira "erro da
// extensão" no chrome://extensions. Vai pro log do painel e segue.
self.addEventListener('unhandledrejection', (event) => {
  event.preventDefault();
  try {
    send('LOG', { level: 'warn', message: `Falha tratada: ${event.reason?.message || event.reason}` });
  } catch { /* ainda sem conexão */ }
});
self.addEventListener('error', (event) => {
  event.preventDefault();
});

/**
 * background/service-worker.js
 * -----------------------------------------------------------------------
 * Ponte entre o backend do painel web (WebSocket em /ext) e a aba do P2B
 * (content script). Não guarda senha, cookies nem tokens de sessão do P2B.
 *
 * Como o backend agora atende várias pessoas ao mesmo tempo (multiusuário),
 * esta extensão precisa se "parear" com a conta certa. Isso acontece em
 * duas etapas:
 *  1. Na 1ª vez, o usuário digita no popup um código de 6 dígitos gerado
 *     no painel (esse código expira em minutos, só serve pra 1ª conexão).
 *  2. O backend devolve um token permanente, que fica guardado localmente
 *     (chrome.storage.local) e é reusado em toda reconexão futura — sem
 *     precisar digitar nada de novo.
 *
 * O Phoenix2Business recarrega a página inteira a cada navegação/pesquisa
 * (não é um app de página única). Por isso o content script não consegue
 * "clicar e esperar o resultado" sozinho — ele só reporta o estado da
 * página atual sempre que carrega. É este arquivo que orquestra a
 * sequência inteira reagindo a cada novo estado reportado.
 * -----------------------------------------------------------------------
 */

const DEFAULT_BACKEND_WS_URL = 'wss://p2b-automation-backend.onrender.com/ext';
const RECONNECT_DELAY_MS = 3000;
const QUERY_TIMEOUT_MS = 20000; // reduzido de 75s pra 20s (03/11/2026) — pedido do Brayan: "se demorar mais de 20 seg pra página responder ele recarrega e tenta o mesmo custcode até conseguir". Seguro porque agora tenta de novo sem limite (reloadP2BTab) em vez de desistir — só muda de quanto em quanto tempo detecta que travou.
const NAV_TIMEOUT_MS = 20000;
const P2B_TAB_PATTERN = 'https://phoenix2businesspcs.timbrasil.com.br/*';

// Duplicado de content/p2b-selectors.js (menuPortabilidadeTexto,
// menuAcompanhamentoTexto, menuStatusSolicitacaoTexto) — o background
// (module) não compartilha escopo global com os content scripts
// (classic scripts), então não dá pra importar esse arquivo direto.
// Se esses textos mudarem lá, precisam mudar aqui também.
const PORTABILIDADE_MENU_TEXTOS = {
  portabilidade: 'Portabilidade',
  acompanhamento: 'Acompanhamento',
  statusSolicitacao: 'Status Solicitações',
};

// --- Mantém o service worker vivo durante esperas longas -----------------
// Manifest V3 encerra o service worker depois de ~30s sem atividade que o
// Chrome reconheça como "trabalho" — e um `setTimeout` comum de até 45s
// (QUERY_TIMEOUT_MS) dentro de uma consulta NÃO conta como atividade pra
// esse relógio. Era essa a causa mais provável de a extensão "cair do
// nada" no meio de uma consulta: o worker morria, a conexão com o backend
// caía junto, e a fila travava até alguém notar e reiniciar na mão.
// Um alarme do chrome.alarms (API reconhecida pelo Chrome) a cada 20s
// reseta esse relógio, e aproveita a chamada pra conferir/reconectar o
// WebSocket e redescobrir a aba do P2B se o worker tiver reiniciado.
const KEEPALIVE_ALARM = 'p2b-keepalive';
const KEEPALIVE_PERIOD_MIN = 20 / 60; // ~20s — abaixo do limite de ociosidade do Chrome

let socket = null;
let p2bTabId = null;
let p2bTabUrl = null;
let extensionToken = null; // token permanente, guardado após parear
let paired = false; // true enquanto esta conexão está autenticada no backend
let lastPairError = null; // mensagem de erro do último PAIR_RESULT malsucedido, pro popup mostrar

// --- Mailbox de estados reportados pelo content script ------------------
// Cada carregamento de página no P2B gera um novo "estado" (form/result/
// error/notfound/other). Como o content script não sobrevive à navegação,
// quem espera o resultado de uma ação que navega é este mailbox.

let latestState = null;
let latestSeq = 0;
const waiters = [];

function recordState(state) {
  latestState = state;
  latestSeq += 1;
  const seq = latestSeq;
  for (let i = waiters.length - 1; i >= 0; i--) {
    const w = waiters[i];
    if (seq > w.sinceSeq && w.predicate(state)) {
      clearTimeout(w.timer);
      waiters.splice(i, 1);
      w.resolve(state);
    }
  }
}

function waitForNextState(predicate, timeoutMs) {
  const sinceSeq = latestSeq;
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      const idx = waiters.findIndex((w) => w.resolve === resolve);
      if (idx >= 0) waiters.splice(idx, 1);
      resolve(null);
    }, timeoutMs);
    waiters.push({ sinceSeq, predicate, resolve, timer });
  });
}

// --- WebSocket com o backend ---------------------------------------------

async function getBackendUrl() {
  const stored = await chrome.storage.local.get('backendUrl');
  return stored.backendUrl || DEFAULT_BACKEND_WS_URL;
}

async function connect() {
  const url = await getBackendUrl();
  socket = new WebSocket(url);

  socket.addEventListener('open', () => {
    if (extensionToken) {
      socket.send(JSON.stringify({ type: 'AUTH', token: extensionToken }));
    }
    // Se não há token nem código pendente, fica esperando o usuário
    // digitar um código no popup (mensagem SET_PAIRING_CODE).
  });

  socket.addEventListener('message', async (event) => {
    let msg;
    try {
      msg = JSON.parse(event.data);
    } catch {
      return;
    }

    if (msg.type === 'PAIR_RESULT') {
      if (msg.payload?.success) {
        paired = true;
        lastPairError = null;
        if (msg.payload.extensionToken) {
          extensionToken = msg.payload.extensionToken;
          await chrome.storage.local.set({ extensionToken });
        }
        send('HELLO', { p2bConnected: Boolean(p2bTabId), currentUrl: p2bTabUrl });
      } else {
        paired = false;
        extensionToken = null;
        lastPairError = msg.payload?.error || 'Não foi possível conectar.';
        await chrome.storage.local.remove('extensionToken');
      }
      return;
    }

    if (!paired) return; // ignora comandos até estar pareado
    await handleServerCommand(msg);
  });

  socket.addEventListener('close', () => {
    socket = null;
    paired = false;
    setTimeout(connect, RECONNECT_DELAY_MS);
  });

  socket.addEventListener('error', () => {
    socket?.close();
  });
}

function send(type, payload) {
  if (socket && socket.readyState === WebSocket.OPEN) {
    try {
      socket.send(JSON.stringify({ type, payload }));
    } catch {
      // 1.5.2: conexão caiu entre a checagem e o envio — o 'close' reconecta.
    }
  }
}

/** Espera o WebSocket com o backend abrir (conectando se preciso). Retorna false se não conseguir a tempo. */
async function waitForSocketOpen(timeoutMs) {
  if (socket && socket.readyState === WebSocket.OPEN) return true;
  if (!socket) connect();
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (socket && socket.readyState === WebSocket.OPEN) return true;
    await sleep(150);
  }
  return false;
}

/** Espera o resultado do pareamento (paired vira true, ou lastPairError é preenchido). */
async function waitForPairingOutcome(timeoutMs) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (paired) return 'paired';
    if (lastPairError) return 'error';
    await sleep(150);
  }
  return 'timeout';
}

async function handleServerCommand(msg) {
  // Se o service worker (MV3) foi reiniciado pelo Chrome entre uma consulta
  // e outra, p2bTabId volta a null em memória mesmo com a aba do P2B ainda
  // aberta de verdade — normalmente isso só seria corrigido no próximo
  // alarme de 20s. Tenta redescobrir a aba agora, na hora, antes de
  // desistir (evita falhar várias consultas seguidas à toa).
  if (!p2bTabId) {
    await rediscoverP2BTab();
  }
  if (!p2bTabId) {
    if (msg.type === 'RUN_SETUP') send('SETUP_RESULT', { success: false, error: 'Aba do P2B não conectada.' });
    if (msg.type === 'RUN_QUERY') send('QUERY_RESULT', { custCode: msg.payload?.custCode, error: 'Aba do P2B não conectada.' });
    return;
  }

  if (msg.type === 'RUN_SETUP') {
    const result = await runSetupFlow(msg.payload?.mode);
    send('SETUP_RESULT', result);
  }

  if (msg.type === 'RUN_QUERY') {
    const custCode = msg.payload?.custCode;
    const mode = msg.payload?.mode;
    send('STEP_UPDATE', { step: 'PESQUISANDO', action: `Pesquisando ${custCode}...` });
    const result = mode === 'portabilidade' ? await runPortabilidadeQueryFlow(custCode) : await runQueryFlow(custCode, mode);
    send('QUERY_RESULT', {
      custCode,
      success: !result.error,
      notFound: Boolean(result.notFound),
      noInvoices: Boolean(result.noInvoices),
      data: result.data || null,
      error: result.error || null,
    });
  }
}

// --- Comandos curtos para o content script atual -------------------------

// Conta falhas seguidas ao falar com o content script da aba atual. Uma
// falha isolada é normal (a página pode estar navegando bem naquele
// instante), mas várias seguidas indicam que a aba travou, foi recarregada
// de um jeito estranho, ou a pessoa navegou ela pra outro site — nesses
// casos é melhor esquecer essa aba e deixar o rediscoverP2BTab (chamado no
// próximo comando ou no alarme de 20s) procurar de novo, em vez de ficar
// preso tentando falar com uma aba que não responde mais.
let noResponseStreak = 0;
const MAX_NO_RESPONSE_STREAK = 3;

function sendToContent(message) {
  return new Promise((resolve) => {
    if (!p2bTabId) return resolve(null);
    chrome.tabs.sendMessage(p2bTabId, message, (response) => {
      if (chrome.runtime.lastError) {
        noResponseStreak += 1;
        if (noResponseStreak >= MAX_NO_RESPONSE_STREAK) {
          send('LOG', { level: 'warn', message: 'Aba do P2B parou de responder — vou procurar ela de novo.' });
          p2bTabId = null;
          p2bTabUrl = null;
          noResponseStreak = 0;
        }
        resolve(null); // normal quando a página já navegou antes da resposta chegar
        return;
      }
      noResponseStreak = 0;
      resolve(response);
    });
  });
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// --- Clique/hover "de verdade" via CDP (chrome.debugger) ------------------
//
// element.dispatchEvent(new MouseEvent(...)) sempre gera eventos com
// isTrusted=false — menus DHTML mais antigos (como o de Portabilidade do
// P2B) às vezes ignoram silenciosamente eventos não confiáveis, o que
// explica a falha intermitente abrindo "Status da Solicitação" pelo menu
// mesmo com a sequência de hover certa. Input.dispatchMouseEvent via CDP
// entra pelo pipeline de input real do Chrome — o evento que chega na
// página tem isTrusted=true, como um clique de verdade do usuário.

const debuggedTabs = new Set();

async function ensureDebuggerAttached(tabId) {
  if (debuggedTabs.has(tabId)) return true;
  try {
    await new Promise((resolve, reject) => {
      chrome.debugger.attach({ tabId }, '1.3', () => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve();
      });
    });
    debuggedTabs.add(tabId);
    return true;
  } catch (err) {
    // "Already attached" acontece se o DevTools do usuário já estiver
    // aberto nessa aba — nesse caso não dá pra usar o debugger da
    // extensão também (o Chrome só permite 1 debugger por aba).
    send('LOG', { level: 'warn', message: `Não consegui anexar o debugger pra clique real: ${err.message}` });
    return false;
  }
}

function cdpSendCommand(tabId, method, params) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand({ tabId }, method, params, (result) => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(result);
    });
  });
}

/** Move o mouse "de verdade" (via CDP) até (x,y) — dispara hover/mouseover reais na página. */
async function realMouseMove(tabId, x, y) {
  if (!(await ensureDebuggerAttached(tabId))) return false;
  try {
    await cdpSendCommand(tabId, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x, y });
    return true;
  } catch {
    return false;
  }
}

/** Clica "de verdade" (via CDP) em (x,y) — move até lá, pressiona e solta o botão esquerdo. */
async function realMouseClick(tabId, x, y) {
  if (!(await ensureDebuggerAttached(tabId))) return false;
  try {
    await cdpSendCommand(tabId, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x, y });
    await cdpSendCommand(tabId, 'Input.dispatchMouseEvent', {
      type: 'mousePressed',
      x,
      y,
      button: 'left',
      clickCount: 1,
    });
    await cdpSendCommand(tabId, 'Input.dispatchMouseEvent', {
      type: 'mouseReleased',
      x,
      y,
      button: 'left',
      clickCount: 1,
    });
    return true;
  } catch {
    return false;
  }
}

chrome.debugger.onDetach.addListener((source) => {
  if (source.tabId) debuggedTabs.delete(source.tabId);
});

/**
 * Garante que a aba está na tela de busca do Controle de Fatura.
 *
 * Em vez de tentar clicar em "nova consulta"/"voltar" (que variam conforme
 * a tela — resultado, erro, não encontrado, sem fatura — e se mostraram
 * pouco confiáveis), sempre que não estivermos já no formulário a
 * automação navega direto para o endereço da tela de busca. É o mesmo
 * endereço para onde o menu leva, então funciona a partir de QUALQUER
 * tela em que a aba esteja.
 */
async function ensureFormReady() {
  let state = await sendToContent({ type: 'P2B_GET_STATE' });
  if (!state) return { success: false, error: 'Sem resposta da aba do P2B.' };
  if (state.kind === 'form') return { success: true, state };

  const openRes = await sendToContent({ type: 'P2B_OPEN_CONTROLE_FATURA' });
  if (!openRes || !openRes.success) {
    return { success: false, error: (openRes && openRes.error) || 'Não foi possível abrir "Controle de Fatura".' };
  }
  state = await waitForNextState((s) => s.kind === 'form', NAV_TIMEOUT_MS);
  if (!state) return { success: false, error: 'Tempo esgotado abrindo Controle de Fatura.' };
  return { success: true, state };
}

/** Garante o tipo de pesquisa "Código do Cliente" selecionado. */
async function ensureCodigoCliente() {
  const formReady = await ensureFormReady();
  if (!formReady.success) return formReady;
  if (formReady.state.codigoClienteSelecionado) return { success: true };

  const res = await sendToContent({ type: 'P2B_SELECT_CODIGO_CLIENTE' });
  if (!res || !res.success) return { success: false, error: (res && res.error) || 'Não foi possível confirmar "Código do Cliente".' };
  return { success: true };
}

/** Garante o tipo de pesquisa "CNPJ" selecionado (modo "CNPJ -> CustCode", novo). */
async function ensureCnpj() {
  const formReady = await ensureFormReady();
  if (!formReady.success) return formReady;
  if (formReady.state.cnpjSelecionado) return { success: true };

  const res = await sendToContent({ type: 'P2B_SELECT_CNPJ' });
  if (!res || !res.success) return { success: false, error: (res && res.error) || 'Não foi possível confirmar "CNPJ".' };
  return { success: true };
}

/**
 * Garante que a aba está na tela de pesquisa "Status da Solicitação"
 * (Portabilidade > Acompanhamento). Diferente do Controle de Fatura, ainda
 * não temos um endereço fixo pra essa tela — então, quando não estamos
 * nela, simula os cliques reais no menu DHTML (hover + clique) em vez de
 * navegar direto. Registra no log o endereço real da tela assim que abre
 * com sucesso, pra facilitar endurecer isso depois (trocar por um link
 * direto, igual ao Controle de Fatura) sem precisar de DevTools.
 */
/**
 * Pede ao content script a posição (x,y) de um item de menu por texto,
 * tentando de novo em intervalos curtos até o item aparecer (ou estourar
 * o timeout) — o submenu DHTML leva um instante pra renderizar depois do
 * hover anterior.
 */
async function waitForMenuItemRect(texto, { timeout = 3000, interval = 150 } = {}) {
  const inicio = Date.now();
  while (Date.now() - inicio < timeout) {
    const rect = await sendToContent({ type: 'P2B_GET_MENU_ITEM_RECT', payload: { texto } });
    if (rect) return rect;
    await sleep(interval);
  }
  return null;
}

/**
 * Abre Portabilidade > Acompanhamento > Status da Solicitação com cliques
 * "de verdade" via CDP (chrome.debugger), não dispatchEvent() do content
 * script — tentativa de corrigir a falha intermitente nesse menu, que
 * pode estar ignorando eventos sintéticos (isTrusted=false).
 */
async function openPortabilidadeStatusViaRealClick() {
  const s = PORTABILIDADE_MENU_TEXTOS;

  const rectPortabilidade = await waitForMenuItemRect(s.portabilidade);
  if (!rectPortabilidade) return { success: false, error: `item de menu "${s.portabilidade}" não encontrado` };
  if (!(await realMouseMove(p2bTabId, rectPortabilidade.x, rectPortabilidade.y))) {
    return { success: false, error: 'não consegui simular o hover (debugger indisponível nessa aba — feche o DevTools se estiver aberto nela)' };
  }

  const rectAcompanhamento = await waitForMenuItemRect(s.acompanhamento);
  if (!rectAcompanhamento) return { success: false, error: `item de menu "${s.acompanhamento}" não encontrado (depois de abrir "${s.portabilidade}")` };
  await realMouseMove(p2bTabId, rectAcompanhamento.x, rectAcompanhamento.y);

  const rectStatus = await waitForMenuItemRect(s.statusSolicitacao);
  if (!rectStatus) return { success: false, error: `item de menu "${s.statusSolicitacao}" não encontrado (depois de abrir "${s.acompanhamento}")` };
  await realMouseClick(p2bTabId, rectStatus.x, rectStatus.y);

  return { success: true };
}

async function ensureFormReadyPortabilidade() {
  let state = await sendToContent({ type: 'P2B_GET_STATE' });
  if (!state) return { success: false, error: 'Sem resposta da aba do P2B.' };
  if (state.kind === 'portabilidade-form') return { success: true, state };

  send('LOG', { level: 'info', message: 'Abrindo Portabilidade > Acompanhamento > Status da Solicitação pelo menu...' });
  const openRes = await openPortabilidadeStatusViaRealClick();
  if (!openRes || !openRes.success) {
    return { success: false, error: (openRes && openRes.error) || 'Não foi possível abrir "Status da Solicitação" pelo menu.' };
  }
  state = await waitForNextState((s) => s.kind === 'portabilidade-form', NAV_TIMEOUT_MS);
  if (!state) return { success: false, error: 'Tempo esgotado abrindo "Status da Solicitação" pelo menu.' };
  send('LOG', { level: 'info', message: `Tela de pesquisa de portabilidade aberta: ${p2bTabUrl}` });
  return { success: true, state };
}

/** Garante o tipo de pesquisa "CNPJ" selecionado na tela de portabilidade. */
async function ensurePortabilidadeCnpj() {
  const formReady = await ensureFormReadyPortabilidade();
  if (!formReady.success) return formReady;
  if (formReady.state.cnpjSelecionado) return { success: true };

  const res = await sendToContent({ type: 'P2B_SELECT_PORTABILIDADE_CNPJ' });
  if (!res || !res.success) return { success: false, error: (res && res.error) || 'Não foi possível confirmar "CNPJ" em Tipo da Consulta.' };
  return { success: true };
}

// Prepara a tela de busca (Código do Cliente/CNPJ/Portabilidade). Antes era
// tentativa única: se desse erro (ex: tela branca), o erro subia na hora e
// o CUST CODE que estava sendo processado era marcado como erro e pulado —
// mesmo a falha não tendo nada a ver com aquele CUST CODE específico, só
// com a tela ainda não estar pronta. Agora, igual runQueryFlow, tenta sem
// limite, recarregando a página de verdade a cada erro (pedido do Brayan
// em 02-03/11/2026: "não quero que pule caso da planilha, quero que ele
// verifique independente do tempo").
async function runSetupFlow(mode) {
  let lastError = 'Erro desconhecido.';
  for (let attempt = 0; ; attempt++) {
    if (attempt > 0) {
      send('STEP_UPDATE', { step: 'TENTANDO_NOVAMENTE', action: `Deu erro preparando a tela (${lastError}), recarregando a página e tentando de novo (tentativa ${attempt + 1})...` });
      send('LOG', { level: 'warn', message: `Erro preparando a tela do P2B (${lastError}) — recarregando a página e tentando de novo (tentativa ${attempt + 1})...` });
      await reloadP2BTab();
      await sleep(200);
    }

    const result =
      mode === 'cnpj' ? await ensureCnpj() : mode === 'portabilidade' ? await ensurePortabilidadeCnpj() : await ensureCodigoCliente();
    if (result.success) return result;
    lastError = result.error || 'Erro desconhecido.';
  }
}

// Recarrega de verdade a aba do P2B (chrome.tabs.reload) e espera o
// content script reportar o estado da página de novo. Diferente de só
// re-clicar nos menus (ensureCodigoCliente/ensureCnpj) — numa tela branca
// ou travada de verdade não tem nada clicável, só um reload de verdade
// recupera. Devolve false se não tinha aba pra recarregar (fecharam ela)
// ou se ela não respondeu dentro do prazo — quem chama trata isso como
// mais uma tentativa que falhou, igual qualquer outro erro. Já espera o
// content script confirmar que a página terminou de carregar (document.
// readyState === 'complete') antes de devolver — por isso quem chama só
// precisa de uma pausa curta depois, não mais os 1,5s/800ms de antes
// (pedido do Brayan em 03/11/2026 pra ficar mais rápido).
function reloadP2BTab(timeoutMs = NAV_TIMEOUT_MS) {
  return new Promise((resolve) => {
    if (!p2bTabId) return resolve(false);
    chrome.tabs.reload(p2bTabId, {}, () => {
      if (chrome.runtime.lastError) return resolve(false);
      waitForNextState(() => true, timeoutMs).then((state) => resolve(Boolean(state)));
    });
  });
}

/**
 * Consulta um CUST CODE. Se der um erro de verdade da página (não "não
 * encontrado" nem "sem fatura" — esses são resultados válidos, não erro),
 * recarrega a aba de verdade e tenta o MESMO CUST CODE de novo — sem
 * limite de tentativas: pedido do Brayan em 02/11/2026 ("não quero mais
 * ela pulando caso, quero que ela tente até conseguir o caso, e toda vez
 * que a página der erro manda ela recarregar a página"). Antes desistia
 * depois de 2 tentativas extras e devolvia erro pra automação pular pro
 * próximo CUST CODE — agora só devolve quando consegue de verdade (ou
 * quando é "não encontrado"/"sem fatura", que são resultados válidos).
 */
async function runQueryFlow(custCode, mode) {
  let lastError = 'Erro desconhecido.';
  const cnpjMode = mode === 'cnpj';

  for (let attempt = 0; ; attempt++) {
    // Recarrega a página ANTES de toda consulta, não só quando dá erro —
    // pedido do Brayan em 03/11/2026 ("manda ela recarregar a página a
    // cada consulta"). Deixa a tela sempre "limpa" antes de pesquisar, em
    // vez de confiar que a navegação do clique em Pesquisar/Avançar foi
    // suficiente da vez anterior.
    if (attempt > 0) {
      send('STEP_UPDATE', { step: 'TENTANDO_NOVAMENTE', action: `Deu erro (${lastError}), recarregando a página e tentando ${custCode} de novo (tentativa ${attempt + 1})...` });
      send('LOG', { level: 'warn', message: `Erro ao consultar ${custCode} (${lastError}) — recarregando a página e tentando de novo (tentativa ${attempt + 1})...` });
    } else {
      send('STEP_UPDATE', { step: 'PREPARANDO', action: `Recarregando a página antes de consultar ${custCode}...` });
    }
    await reloadP2BTab();
    await sleep(200);

    const setup = cnpjMode ? await ensureCnpj() : await ensureCodigoCliente();
    if (!setup.success) {
      lastError = setup.error;
      continue;
    }

    const submitRes = cnpjMode
      ? await sendToContent({ type: 'P2B_SUBMIT_CNPJ_QUERY', payload: { cnpj: custCode } })
      : await sendToContent({ type: 'P2B_SUBMIT_QUERY', payload: { custCode } });
    if (cnpjMode && submitRes?.tipoSelecionado) {
      send('LOG', { level: 'info', message: `Tipo de pesquisa marcado: "${submitRes.tipoSelecionado}" — digitou "${submitRes.valorDigitado}".` });
    }
    if (submitRes && submitRes.success === false) {
      lastError = submitRes.error;
      continue;
    }

    const resultState = await waitForNextState(
      (s) => s.kind === 'result' || s.kind === 'error' || s.kind === 'notfound' || s.kind === 'no-invoices',
      QUERY_TIMEOUT_MS
    );
    if (!resultState) {
      lastError = 'Tempo esgotado aguardando o resultado da consulta no P2B.';
      continue;
    }

    // "não encontrado" e "sem fatura" são resultados válidos — não é erro,
    // não tenta de novo.
    if (resultState.kind === 'notfound') return { custCode, notFound: true, data: null };
    if (resultState.kind === 'no-invoices') return { custCode, noInvoices: true, data: null };

    if (resultState.kind === 'error') {
      lastError = resultState.message;
      continue; // erro de verdade: tenta de novo (próxima volta do loop)
    }

    return { custCode, notFound: false, data: resultState.data };
  }
}

// Status que, se aparecerem em alguma linha do detalhe, encerram a busca
// entre bolinhas empatadas (mesma data mais recente). Mesma lista de
// statusDecisivo() no backend (portabilidadeRules.js).
const STATUS_DECISIVOS = ['falha parcial', 'portad', 'conflit', 'andamento', 'enviando'];

function temStatusDecisivo(data) {
  const linhas = (data && data.agrupadores && data.agrupadores.length) ? data.agrupadores : [{ status: data && data.status }];
  return linhas.some((l) => {
    const s = String(l.status || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    return STATUS_DECISIVOS.some((k) => s.includes(k));
  });
}

/**
 * Pesquisa o CNPJ e abre o detalhe da bolinha `indice` entre as que têm a
 * Data Solicitação mais recente. Devolve { data, empatadas } ou { error }.
 */
async function abrirDetalhePortabilidade(cnpj, indice) {
  const setup = await ensurePortabilidadeCnpj();
  if (!setup.success) return { error: setup.error };

  const submitRes = await sendToContent({ type: 'P2B_SUBMIT_PORTABILIDADE_CNPJ_QUERY', payload: { cnpj } });
  if (submitRes && submitRes.success === false) return { error: submitRes.error };

  let state = await waitForNextState(
    (s) =>
      s.kind === 'portabilidade-results' ||
      s.kind === 'portabilidade-detail' ||
      (s.kind === 'portabilidade-form' && s.semResultado) ||
      s.kind === 'notfound' ||
      s.kind === 'error',
    QUERY_TIMEOUT_MS
  );
  if (!state) return { error: 'Tempo esgotado aguardando o resultado da pesquisa de portabilidade.' };
  if (state.kind === 'error') return { error: state.message };
  if (state.kind === 'notfound' || state.kind === 'portabilidade-form') return { notFound: true };

  let empatadas = 1;
  if (state.kind === 'portabilidade-results') {
    const selRes = await sendToContent({ type: 'P2B_SELECT_PORTABILIDADE_RESULT', payload: { indice } });
    if (selRes && selRes.success === false) return { error: selRes.error };
    empatadas = (selRes && selRes.empatadas) || 1;
    state = await waitForNextState((s) => s.kind === 'portabilidade-detail' || s.kind === 'notfound' || s.kind === 'error', NAV_TIMEOUT_MS);
    if (!state) return { error: 'Tempo esgotado abrindo o detalhe da solicitação.' };
    if (state.kind === 'error') return { error: state.message };
    if (state.kind === 'notfound') return { notFound: true };
  }

  send('LOG', { level: 'info', message: `Tela de detalhe da portabilidade aberta: ${p2bTabUrl}` });
  const data = state.data || {};
  if (!data.status && !(data.agrupadores || []).length) {
    return { error: 'Abriu o detalhe, mas não consegui ler o campo "Status".' };
  }
  return { data, empatadas };
}

/**
 * Consulta um CNPJ na tela de Status da Solicitação (Portabilidade): abre o
 * detalhe da bolinha com a Data Solicitação mais recente. Se duas ou mais
 * bolinhas têm essa mesma data, testa uma por vez (pesquisando o CNPJ de
 * novo) até achar uma com status decisivo (PORTADO, FALHA PARCIAL,
 * CONFLITO, EM ANDAMENTO, ENVIANDO); se nenhuma tiver, usa a primeira.
 */
async function runPortabilidadeQueryFlow(cnpj) {
  let lastError = 'Erro desconhecido.';
  let primeira = null;
  let indice = 0;
  let empatadas = 1;
  let tentativasErro = 0;

  while (indice < empatadas) {
    if (tentativasErro > 0) {
      send('STEP_UPDATE', { step: 'TENTANDO_NOVAMENTE', action: `Deu erro (${lastError}), recarregando a página e tentando CNPJ ${cnpj} de novo (tentativa ${tentativasErro + 1})...` });
      send('LOG', { level: 'warn', message: `Erro ao consultar portabilidade do CNPJ ${cnpj} (${lastError}) — recarregando a página e tentando de novo (tentativa ${tentativasErro + 1})...` });
      await reloadP2BTab();
      await sleep(200);
    }

    const res = await abrirDetalhePortabilidade(cnpj, indice);
    if (res.error) {
      lastError = res.error;
      tentativasErro++;
      continue; // sem limite — tenta até conseguir (pedido do Brayan em 02/11/2026)
    }
    tentativasErro = 0;
    if (res.notFound) {
      if (primeira) break; // bolinha empatada sem nada: fica com a 1ª
      send('LOG', { level: 'info', message: `CNPJ ${cnpj}: nenhuma solicitação encontrada (LINHA NOVA).` });
      return { custCode: cnpj, notFound: true };
    }
    empatadas = res.empatadas;
    if (!primeira) primeira = res.data;
    if (temStatusDecisivo(res.data)) return { custCode: cnpj, notFound: false, data: res.data };

    indice++;
    if (indice < empatadas) {
      send('LOG', { level: 'info', message: `Bolinha ${indice} de ${empatadas} (mesma data) sem status decisivo — testando a próxima.` });
    }
  }

  if (primeira) return { custCode: cnpj, notFound: false, data: primeira };
  return { custCode: cnpj, error: lastError };
}

// --- Mensagens vindas do content script e do popup ------------------------

// Impede o Chrome de "descarregar" (Memory Saver / economia de memória) a
// aba do P2B quando ela fica em segundo plano por um tempo — sem isso, a
// aba virava um "zumbi" sem processo nenhum rodando até a pessoa clicar
// nela de novo, travando a fila até alguém notar e voltar pra aba na mão.
function manterAbaAcordada(tabId) {
  chrome.tabs.update(tabId, { autoDiscardable: false }, () => {
    if (chrome.runtime.lastError) {
      // ignora — não é crítico, só uma otimização
    }
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'P2B_STATE') {
    if (sender.tab) {
      p2bTabId = sender.tab.id;
      p2bTabUrl = message.url || p2bTabUrl;
      manterAbaAcordada(p2bTabId);
      if (paired) send('STATUS', { p2bConnected: true, currentUrl: p2bTabUrl });
    }
    recordState(message.payload);
    return false;
  }

  if (message.type === 'GET_POPUP_STATUS') {
    sendResponse({
      backendConnected: Boolean(socket && socket.readyState === WebSocket.OPEN),
      paired,
      p2bConnected: Boolean(p2bTabId),
      lastPairError,
    });
    return true;
  }

  if (message.type === 'SET_PAIRING_CODE') {
    (async () => {
      const code = String(message.code || '').trim();
      lastPairError = null;

      const ok = await waitForSocketOpen(5000);
      if (!ok) {
        lastPairError = 'Não foi possível conectar ao backend. Confira se ele está rodando.';
        sendResponse({ ok: false, error: lastPairError });
        return;
      }

      socket.send(JSON.stringify({ type: 'PAIR', code }));
      const result = await waitForPairingOutcome(8000);
      if (result === 'timeout') {
        lastPairError = 'Tempo esgotado aguardando resposta do backend.';
        sendResponse({ ok: false, error: lastPairError });
        return;
      }
      sendResponse({ ok: result === 'paired', error: result === 'paired' ? null : lastPairError });
    })();
    return true;
  }

  if (message.type === 'FORGET_PAIRING') {
    (async () => {
      extensionToken = null;
      paired = false;
      await chrome.storage.local.remove('extensionToken');
      socket?.close();
      sendResponse({ ok: true });
    })();
    return true;
  }

  return false;
});

chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === p2bTabId) {
    p2bTabId = null;
    p2bTabUrl = null;
    latestState = null;
    if (paired) send('STATUS', { p2bConnected: false, currentUrl: null });
  }
});

// Antes, se alguém navegasse a aba acompanhada pra fora do P2B (outro site,
// outra aba interna), a extensão só percebia quando a aba fosse FECHADA —
// até lá, ficava tentando falar com uma aba que não é mais do P2B.
const p2bUrlRegex = new RegExp('^' + P2B_TAB_PATTERN.replace(/[.*+?^${}()|[\]\\]/g, (c) => (c === '*' ? '.*' : '\\' + c)) + '$');
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (tabId !== p2bTabId || !changeInfo.url) return;
  if (!p2bUrlRegex.test(changeInfo.url)) {
    p2bTabId = null;
    p2bTabUrl = null;
    latestState = null;
    if (paired) send('STATUS', { p2bConnected: false, currentUrl: null });
  }
});

/**
 * Procura uma aba do P2B já aberta e pede o estado atual dela — cobre o
 * caso do service worker reiniciar (MV3) com a aba continuando aberta:
 * sem isso, p2bTabId ficava null até a pessoa navegar/recarregar a aba
 * manualmente, e qualquer comando chegava nesse meio tempo com "Aba do
 * P2B não conectada" mesmo com a aba certinha na tela.
 */
async function rediscoverP2BTab() {
  if (p2bTabId) return; // já sabe de uma aba — nada a fazer
  let tabs;
  try {
    tabs = await chrome.tabs.query({ url: P2B_TAB_PATTERN });
  } catch {
    return;
  }
  if (!tabs || tabs.length === 0) return;

  const tab = tabs[0];
  manterAbaAcordada(tab.id);
  if (tab.discarded) {
    // Aba descarregada pelo Chrome (Memory Saver) — não tem content script
    // vivo até recarregar. Recarrega e espera um instante antes de tentar
    // falar com ela, senão a 1ª tentativa falha à toa.
    chrome.tabs.reload(tab.id);
    await sleep(1000);
  }
  // Tenta algumas vezes com pausa curta: logo após um reinício do service
  // worker o content script pode ainda não ter processado a mensagem
  // anterior / acabado de injetar, e uma única tentativa falhava sem
  // necessidade (o alarme periódico de 20s acabava corrigindo sozinho
  // bem depois, deixando consultas falharem à toa nesse meio tempo).
  let response = null;
  for (let tentativa = 0; tentativa < 4 && !response; tentativa++) {
    if (tentativa > 0) await sleep(300);
    response = await new Promise((resolve) => {
      chrome.tabs.sendMessage(tab.id, { type: 'P2B_GET_STATE' }, (res) => {
        resolve(chrome.runtime.lastError ? null : res);
      });
    });
  }
  if (!response) return; // content script ainda não carregou nessa aba — tenta de novo no próximo alarme

  p2bTabId = tab.id;
  p2bTabUrl = tab.url || p2bTabUrl;
  recordState(response);
  if (paired) send('STATUS', { p2bConnected: true, currentUrl: p2bTabUrl });
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== KEEPALIVE_ALARM) return;
  if (!socket || socket.readyState === WebSocket.CLOSED) connect();
  rediscoverP2BTab();
});

// --- Inicialização ---------------------------------------------------------

(async function init() {
  const stored = await chrome.storage.local.get('extensionToken');
  extensionToken = stored.extensionToken || null;
  chrome.alarms.create(KEEPALIVE_ALARM, { periodInMinutes: KEEPALIVE_PERIOD_MIN });
  connect();
  rediscoverP2BTab();
})();

// init() só roda quando o worker é carregado do zero. onStartup/onInstalled
// cobrem os outros gatilhos de (re)início do Chrome/extensão — sem isso, o
// alarme podia não existir ainda num desses casos e a extensão ficava sem
// o keepalive até a próxima reinstalação.
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(KEEPALIVE_ALARM, { periodInMinutes: KEEPALIVE_PERIOD_MIN });
});
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(KEEPALIVE_ALARM, { periodInMinutes: KEEPALIVE_PERIOD_MIN });
});
