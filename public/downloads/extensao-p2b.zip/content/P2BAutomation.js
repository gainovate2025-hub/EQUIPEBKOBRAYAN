/**
 * P2BAutomation.js
 * -----------------------------------------------------------------------
 * Toda a lógica específica do fluxo do Phoenix2Business (P2B) fica isolada
 * aqui. Os seletores vêm exclusivamente de p2b-selectors.js.
 *
 * IMPORTANTE (descoberto testando ao vivo contra o sistema real): este é
 * um app antigo baseado em frames/servlets — CADA clique no menu e CADA
 * pesquisa recarrega a página inteira (não é AJAX). Isso significa que o
 * content script é destruído e recriado do zero a cada navegação. Por
 * isso este módulo NÃO tenta "clicar e esperar o resultado" numa única
 * função contínua (isso quebraria no meio, quando a página recarrega).
 * Em vez disso, cada método aqui é uma ação curta e imediata sobre a
 * página ATUAL; quem orquestra a sequência entre uma página e a próxima
 * é o background/service-worker.js, reagindo a cada novo carregamento.
 *
 * Este módulo só executa ações que um usuário autenticado normalmente
 * executaria manualmente na tela (clicar, digitar, ler texto visível).
 * Não faz chamadas diretas a APIs do P2B, não lê cookies/tokens de sessão
 * e não tenta contornar nenhum mecanismo de segurança.
 * -----------------------------------------------------------------------
 */

function queryFirst(selectorList) {
  for (const sel of selectorList) {
    try {
      const el = document.querySelector(sel);
      if (el) return el;
    } catch {
      /* seletor inválido, ignora */
    }
  }
  return null;
}

/** Define o valor de um input de forma compatível com apps que escutam eventos nativos. */
function setNativeValue(element, value) {
  const proto = window.HTMLInputElement.prototype;
  const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
  if (descriptor && descriptor.set) {
    descriptor.set.call(element, value);
  } else {
    element.value = value;
  }
  element.dispatchEvent(new Event('input', { bubbles: true }));
  element.dispatchEvent(new Event('change', { bubbles: true }));
}

/** Localiza a tabela de resultado pelo texto do cabeçalho (ex: "CustCode"), sem depender de id fixo. */
function findResultsTable(headerText, headerClass) {
  const headers = document.getElementsByClassName(headerClass);
  for (const th of headers) {
    if ((th.textContent || '').trim().toLowerCase() === headerText.toLowerCase()) {
      return th.closest('table');
    }
  }
  return null;
}

function buildColumnIndexMap(headerRow) {
  const map = {};
  Array.from(headerRow.cells).forEach((cell, idx) => {
    map[cell.textContent.trim().toLowerCase()] = idx;
  });
  return map;
}

function findColumnIndex(columnMap, candidates) {
  for (const name of candidates) {
    if (name.toLowerCase() in columnMap) return columnMap[name.toLowerCase()];
  }
  return -1;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function fireMouseEvent(el, type) {
  el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
}

/**
 * Paira sobre `elementoPai` (disparando mouseover/mouseenter/mousemove —
 * alguns menus DHTML só abrem o submenu com a sequência completa, não só
 * mouseover) e fica tentando de novo, em intervalos curtos, até o item de
 * submenu com `textoAlvo` aparecer no DOM — em vez de um sleep() fixo que
 * pode não dar tempo suficiente pro menu renderizar (causa já conhecida de
 * timeout intermitente abrindo "Status da Solicitação" pelo menu).
 */
async function hoverUntilMenuItemAppears(elementoPai, textoAlvo, { timeout = 3000, interval = 150 } = {}) {
  const inicio = Date.now();
  while (Date.now() - inicio < timeout) {
    fireMouseEvent(elementoPai, 'mouseover');
    fireMouseEvent(elementoPai, 'mouseenter');
    fireMouseEvent(elementoPai, 'mousemove');
    await sleep(interval);
    const item = findMenuItemByText(textoAlvo);
    if (item) return item;
  }
  return null;
}

/**
 * Acha o botão "Pesquisar" da tela de portabilidade. Confirmado ao vivo em
 * 07/10/2026 (HTML real mandado pelo usuário): aqui NÃO é um
 * <input type="image"> nem um <button> — é uma <img> comum com
 * onclick="pesquisar(...)" e alt="pesquisar":
 *   <img name="btCnt" class="imagem" alt="pesquisar" onclick="pesquisar(...)">
 * Clicar numa <img> assim (via .click()) funciona normalmente — o
 * navegador dispara o onclick dela igual dispararia num botão de verdade.
 * Tenta esse padrão exato primeiro (nome/alt), depois o id do formulário
 * de fatura (#bt-pesquisar, caso essa tela um dia reaproveite esse
 * componente), e só por último a busca genérica por texto.
 */
function findPesquisarButton(textoAlternativo) {
  let btn = document.querySelector('img[name="btCnt"], img[alt="pesquisar" i]');
  if (btn) return btn;
  btn = document.querySelector('#bt-pesquisar');
  if (btn) return btn;
  const imagens = document.querySelectorAll('input[type="image"]');
  if (imagens.length === 1) return imagens[0];
  return findButtonByText(textoAlternativo);
}

/**
 * O botão "Detalhar" da tela de resultados da portabilidade é a mesma
 * estrutura legada do "pesquisar" (<img onclick="...">, não <input
 * type="image"> nem <button>) — findButtonByText não acha <img> solta.
 * Confirmado ao vivo: <img name="btCnt" alt="Detalhar" onclick="detalhar(...)">.
 */
function findDetalharButton(textoAlternativo) {
  // IMPORTANTE: "Pesquisar" (ainda visível no topo da tela de resultados)
  // e "Detalhar" têm o MESMO name="btCnt" — um seletor CSS combinado tipo
  // 'img[alt="detalhar" i], img[name="btCnt"]' pode devolver o Pesquisar
  // por engano (ele vem antes no DOM, e querySelector só olha ordem no
  // documento, não qual parte do seletor bateu). Por isso busca
  // EXCLUSIVAMENTE por alt="detalhar" primeiro, isolado, antes de
  // qualquer fallback mais genérico.
  let btn = document.querySelector('img[alt="detalhar" i]');
  if (btn) return btn;
  btn = document.querySelector('img[name="btCnt"]');
  if (btn) return btn;
  return findButtonByText(textoAlternativo);
}

/** Acha o botão/link clicável (input ou <a>/<button>) cujo texto/valor visível bate com `texto`. */
function findButtonByText(texto) {
  const alvo = texto.trim().toLowerCase();
  const candidatos = document.querySelectorAll(
    'input[type="submit"], input[type="button"], input[type="image"], button, a'
  );
  for (const el of candidatos) {
    const rotulo = (el.value || el.textContent || el.title || el.alt || '').trim().toLowerCase();
    if (rotulo === alvo || rotulo.includes(alvo)) return el;
  }
  return null;
}

/**
 * Acha um item do menu DHTML cujo texto visível contém TODAS as palavras de
 * `texto` (não exige frase exata — testado ao vivo em 07/10/2026: o item
 * real é "Status Solicitações", sem "da" e no plural, diferente do que a
 * gente imaginou de início). Entre os que baterem, escolhe o de texto MAIS
 * CURTO, pra não pegar um container grande que só por acaso também contém
 * essas palavras em algum lugar dentro.
 */
function findMenuItemByText(texto) {
  const palavras = texto.trim().toLowerCase().split(/\s+/).filter(Boolean);
  const candidatos = document.querySelectorAll('a, td, div, span, li');
  let melhor = null;
  let melhorTamanho = Infinity;
  for (const el of candidatos) {
    const t = (el.textContent || '').trim().toLowerCase();
    if (!t || !palavras.every((p) => t.includes(p))) continue;
    if (t.length < melhorTamanho) {
      melhor = el;
      melhorTamanho = t.length;
    }
  }
  return melhor;
}

function normalizarRotulo(s) {
  return (s || '').trim().toLowerCase().replace(/:\s*$/, '').trim();
}

class P2BAutomation {
  constructor(selectors) {
    this.selectors = selectors;
  }

  /** Confirma que este documento/frame é realmente uma tela do Phoenix2Business
   * (o app usa frameset; o frame externo fica sempre vazio). */
  isP2BFrame() {
    return this.selectors.markerElements.some((sel) => {
      try {
        return Boolean(document.querySelector(sel));
      } catch {
        return false;
      }
    });
  }

  /**
   * Coordenadas (x,y do centro, relativas ao viewport) de um item de menu
   * achado por texto — usado pro background simular um clique/hover
   * "de verdade" via chrome.debugger (Input.dispatchMouseEvent), que o
   * site enxerga como clique real do usuário, em vez de dispatchEvent()
   * (sempre "não confiável"/isTrusted=false, que menus DHTML mais antigos
   * às vezes ignoram silenciosamente).
   */
  getMenuItemRect(texto) {
    const el = findMenuItemByText(texto);
    if (!el) return null;
    const r = el.getBoundingClientRect();
    if (r.width === 0 && r.height === 0) return null;
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  }

  /**
   * Descreve a página ATUAL sem esperar nada (chamado logo que o content
   * script carrega, e sob demanda pelo background). Nunca navega.
   */
  detectPageState() {
    // Portabilidade usa telas totalmente diferentes do fluxo de fatura/CNPJ
    // (nunca tem campoCustCode nem a tabela de CustCode) — por isso é
    // checado antes, sem interferir no resto quando essas telas não batem.
    //
    // A tela de RESULTADOS é checada primeiro: ela também é uma tabela e
    // pode ter colunas fora da área visível (ex: "Status"), então se
    // checássemos "é a tela de detalhe?" primeiro, um "Status" perdido
    // nessa tabela de resultados poderia ser confundido com o campo de
    // status da tela de detalhe de verdade — travando a automação antes
    // de selecionar a linha e clicar "detalhar".
    if (this.findPortabilidadeResultsTable()) {
      return { kind: 'portabilidade-results' };
    }
    if (this.isPortabilidadeDetailPage()) {
      return { kind: 'portabilidade-detail', data: this.extractPortabilidadeData() };
    }
    if (this.isPortabilidadeForm()) {
      // "Nenhuma Solicitação foi encontrada" aparece NA PRÓPRIA tela do
      // formulário (e pode já estar lá antes de pesquisar). Por isso é só
      // uma marca no estado do formulário: o service-worker só trata como
      // "não encontrado" quando ela aparece logo DEPOIS de pesquisar.
      const textoPagina = (document.body?.innerText || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
      return {
        kind: 'portabilidade-form',
        cnpjSelecionado: this.confirmPortabilidadeCnpjSelected(),
        semResultado: /nenhum[a]?\s+(solicitac\w*|registro\w*|resultado\w*)[^.\n]{0,40}encontrad/.test(textoPagina),
      };
    }

    const erro = queryFirst(this.selectors.mensagemErro);
    if (erro && erro.textContent.trim()) {
      const text = erro.textContent.trim();
      const lower = text.toLowerCase();
      if (lower.includes(this.selectors.textoNaoEncontrado)) return { kind: 'notfound', message: text };
      if (lower.includes(this.selectors.textoSemFatura)) return { kind: 'no-invoices', message: text };
      return { kind: 'error', message: text };
    }

    const table = findResultsTable(this.selectors.tabelaResultadoHeaderText, this.selectors.tabelaResultadoHeaderClass);
    if (table && table.rows.length > 1) {
      return { kind: 'result', data: this.extractInvoiceData(table) };
    }

    if (queryFirst(this.selectors.campoCustCode)) {
      return {
        kind: 'form',
        codigoClienteSelecionado: this.confirmCustomerCodeSelected(),
        cnpjSelecionado: this.confirmCnpjSelected(),
      };
    }

    return { kind: 'other' };
  }

  // --- Ações que NÃO navegam (é seguro esperar a resposta) -------------

  selectCustomerCode() {
    const select = queryFirst(this.selectors.tipoPesquisaSelect);
    if (!select) return { success: false, error: 'seletor de tipo de pesquisa não encontrado' };

    const targetValue = this.selectors.tipoPesquisaCodigoClienteValue;
    let option = Array.from(select.options).find((o) => o.value === targetValue);
    if (!option) {
      option = Array.from(select.options).find(
        (o) => o.textContent.trim().toLowerCase() === this.selectors.tipoPesquisaCodigoClienteLabel.toLowerCase()
      );
    }
    if (!option) return { success: false, error: `opção "${this.selectors.tipoPesquisaCodigoClienteLabel}" não encontrada` };

    select.value = option.value;
    select.dispatchEvent(new Event('change', { bubbles: true }));
    return { success: this.confirmCustomerCodeSelected() };
  }

  confirmCustomerCodeSelected() {
    const select = queryFirst(this.selectors.tipoPesquisaSelect);
    if (!select) return false;
    const selected = select.options[select.selectedIndex];
    return Boolean(
      selected &&
        (selected.value === this.selectors.tipoPesquisaCodigoClienteValue ||
          selected.textContent.trim().toLowerCase() === this.selectors.tipoPesquisaCodigoClienteLabel.toLowerCase())
    );
  }

  // --- Modo "CNPJ -> CustCode" (novo, 28/09/2026) — mesma tela, mesmo
  // campo "valor", só troca o tipo de pesquisa e o que é lido do resultado.
  // Não reaproveita/mexe nos métodos acima (Código do Cliente).

  selectCnpjSearch() {
    const select = queryFirst(this.selectors.tipoPesquisaSelect);
    if (!select) return { success: false, error: 'seletor de tipo de pesquisa não encontrado' };

    const targetValue = this.selectors.tipoPesquisaCnpjValue;
    let option = targetValue ? Array.from(select.options).find((o) => o.value === targetValue) : null;
    if (!option) {
      option = Array.from(select.options).find(
        (o) => o.textContent.trim().toLowerCase() === this.selectors.tipoPesquisaCnpjLabel.toLowerCase()
      );
    }
    if (!option) return { success: false, error: `opção "${this.selectors.tipoPesquisaCnpjLabel}" não encontrada` };

    select.value = option.value;
    select.dispatchEvent(new Event('change', { bubbles: true }));
    return { success: this.confirmCnpjSelected() };
  }

  confirmCnpjSelected() {
    const select = queryFirst(this.selectors.tipoPesquisaSelect);
    if (!select) return false;
    const selected = select.options[select.selectedIndex];
    return Boolean(
      selected &&
        (selected.value === this.selectors.tipoPesquisaCnpjValue ||
          selected.textContent.trim().toLowerCase() === this.selectors.tipoPesquisaCnpjLabel.toLowerCase())
    );
  }

  // --- Ações que NAVEGAM (a página recarrega; não dá pra esperar aqui) -

  /** Abre a tela "Consultas > Controle de Fatura" (a página vai recarregar). */
  openInvoiceControl() {
    window.location.href = this.selectors.controleFaturaUrl;
    return { success: true };
  }

  /** Garante "Código do Cliente" selecionado, digita o CUST CODE e clica Pesquisar (a página vai recarregar). */
  submitQuery(custCode) {
    if (!this.confirmCustomerCodeSelected()) {
      const sel = this.selectCustomerCode();
      if (!sel.success) return sel;
    }
    const input = queryFirst(this.selectors.campoCustCode);
    if (!input) return { success: false, error: 'campo de CUST CODE não encontrado' };
    setNativeValue(input, custCode);

    const btn = queryFirst(this.selectors.botaoPesquisar);
    if (!btn) return { success: false, error: 'botão "Pesquisar" não encontrado' };
    btn.click();
    return { success: true };
  }

  /** Garante "CNPJ" selecionado, digita o CNPJ e clica Pesquisar (a página vai recarregar). */
  /** Texto visível da opção marcada agora no seletor de tipo de pesquisa (pra log/diagnóstico). */
  tipoPesquisaTextoAtual() {
    const select = queryFirst(this.selectors.tipoPesquisaSelect)
    const selected = select?.options[select.selectedIndex]
    return selected ? selected.textContent.trim() : '(select não encontrado)'
  }

  submitCnpjQuery(cnpj) {
    // Nunca confia num "já tá selecionado" de antes — marca CNPJ de novo
    // sempre, confere que colou de verdade (até 2 tentativas), e só
    // desiste se realmente não conseguir. Evita pesquisar com o tipo
    // errado sem perceber.
    let marcado = this.confirmCnpjSelected()
    for (let tentativa = 1; tentativa <= 2 && !marcado; tentativa++) {
      const sel = this.selectCnpjSearch()
      if (!sel.success) return sel
      marcado = this.confirmCnpjSelected()
    }
    const tipoAtual = this.tipoPesquisaTextoAtual()
    if (!marcado) {
      return { success: false, error: `não consegui marcar "CNPJ" — ficou em "${tipoAtual}"` }
    }

    const input = queryFirst(this.selectors.campoCustCode); // mesmo campo "valor" dos outros tipos de pesquisa
    if (!input) return { success: false, error: 'campo de valor não encontrado' };
    const valorLimpo = String(cnpj).replace(/\D/g, '')
    setNativeValue(input, valorLimpo);
    if (input.value !== valorLimpo) {
      return { success: false, error: `campo não ficou com o valor certo — ficou "${input.value}"`, tipoSelecionado: tipoAtual };
    }

    const btn = queryFirst(this.selectors.botaoPesquisar);
    if (!btn) return { success: false, error: 'botão "Pesquisar" não encontrado' };
    btn.click();
    return { success: true, tipoSelecionado: tipoAtual, valorDigitado: input.value };
  }

  extractInvoiceData(table) {
    const headerRow = table.rows[0];
    const columnMap = buildColumnIndexMap(headerRow);
    const cols = this.selectors.colunasTabelaResultado;

    const telefoneIdx = findColumnIndex(columnMap, cols.telefone);
    const vencimentoIdx = findColumnIndex(columnMap, cols.dataFatura);
    const valorIdx = findColumnIndex(columnMap, cols.valorFatura);
    const numeroIdx = findColumnIndex(columnMap, cols.numeroFatura);
    // Coluna "CustCode" — o mesmo texto usado pra achar a tabela (ver
    // tabelaResultadoHeaderText) também é uma coluna de dado. Só é lida de
    // verdade no modo "CNPJ -> CustCode"; nos outros modos essa informação
    // já é conhecida de antemão e simplesmente não é usada.
    const custCodeIdx = findColumnIndex(columnMap, [this.selectors.tabelaResultadoHeaderText.toLowerCase()]);

    const cellText = (row, idx) => (idx >= 0 && row.cells[idx] ? row.cells[idx].textContent.trim() : '');

    // Confirmado ao vivo: quando o cliente tem mais de um telefone
    // cadastrado, a célula mostra os dois separados por <br> — mas
    // .textContent junta os dois SEM espaço nenhum entre eles (<br> não
    // vira nenhum caractere), grudando os números (ex: "34998151836" +
    // "34999083784" virava "3499815183634999083784"). Lê o HTML da
    // célula, separa pelas quebras de linha e pega só o PRIMEIRO
    // telefone, em vez do texto inteiro colado.
    const linhasDaCelula = (row, idx) => {
      if (idx < 0 || !row.cells[idx]) return []
      const html = row.cells[idx].innerHTML || ''
      return html
        .split(/<br\s*\/?>/i)
        .map((pedaco) => {
          const div = document.createElement('div')
          div.innerHTML = pedaco
          return (div.textContent || '').trim()
        })
        .filter(Boolean)
    }
    const primeiroTelefone = (row, idx) => linhasDaCelula(row, idx)[0] || ''

    // Um cliente pode ter mais de uma fatura em aberto (uma linha por fatura,
    // a 1ª linha é o cabeçalho). Pega todas, depois ordena da mais antiga pra
    // mais nova — "Fatura 1" sempre é a mais antiga, não a que aparece
    // primeiro na tela (a ordem na tela não é garantida).
    const faturas = [];
    let telefone = '';
    let custcode = '';
    // Alguns CNPJs têm mais de um CustCode vinculado (ex: duas linhas de
    // contrato diferentes) — guarda TODOS os valores distintos que
    // aparecerem na coluna CustCode, na ordem em que aparecem na tabela,
    // não só o primeiro.
    const custcodes = [];
    for (let i = 1; i < table.rows.length; i++) {
      const row = table.rows[i];
      const vencimento = cellText(row, vencimentoIdx);
      const valor = cellText(row, valorIdx);
      const numero = cellText(row, numeroIdx);
      if (!telefone) telefone = primeiroTelefone(row, telefoneIdx);
      // A célula do CustCode pode ter mais de um valor na MESMA célula
      // (separados por <br>, igual o telefone) — não só uma linha de tabela
      // por CustCode. Pega todos os valores de todas as células.
      for (const custcodeDaLinha of linhasDaCelula(row, custCodeIdx)) {
        if (!custcode) custcode = custcodeDaLinha;
        if (!custcodes.includes(custcodeDaLinha)) custcodes.push(custcodeDaLinha);
      }
      if (vencimento || valor || numero) faturas.push({ numero, vencimento, valor });
    }

    function parseDataBr(str) {
      const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(str || '');
      if (!m) return null;
      return new Date(`${m[3]}-${m[2]}-${m[1]}T00:00:00`).getTime();
    }

    faturas.sort((a, b) => {
      const da = parseDataBr(a.vencimento);
      const db = parseDataBr(b.vencimento);
      if (da === null && db === null) return 0;
      if (da === null) return 1; // sem data válida vai pro fim
      if (db === null) return -1;
      return da - db; // mais antiga primeiro
    });
    faturas.length = Math.min(faturas.length, 4);

    const cnpjEl = queryFirst(this.selectors.campoCnpj);
    const statusEl = Array.from(document.getElementsByClassName('texto12')).find((el) =>
      (el.textContent || '').toLowerCase().includes('fatura')
    );

    return {
      cnpj: cnpjEl ? cnpjEl.textContent.trim() : '',
      custcode,
      custcodes,
      telefone,
      statusFatura: statusEl ? statusEl.textContent.trim() : '',
      numero: faturas[0]?.numero || '',
      dataFatura: faturas[0]?.vencimento || '',
      valorFatura: faturas[0]?.valor || '',
      vencimento1: faturas[0]?.vencimento || '',
      vencimento2: faturas[1]?.vencimento || '',
      vencimento3: faturas[2]?.vencimento || '',
      vencimento4: faturas[3]?.vencimento || '',
      valor1: faturas[0]?.valor || '',
      valor2: faturas[1]?.valor || '',
      valor3: faturas[2]?.valor || '',
      valor4: faturas[3]?.valor || '',
    };
  }

  // --- Modo "Portabilidade" (07/10/2026) --------------------------------
  // Tela diferente da de fatura/CNPJ (Portabilidade > Acompanhamento >
  // Status da Solicitação). Nunca navegada ao vivo por este código antes —
  // tudo aqui casa por texto visível, não por id, e qualquer falha vira
  // uma mensagem de erro descritiva (visível no log da automação).

  /** Abre a tela de Status da Solicitação simulando os cliques reais no menu (hover + clique). */
  async openPortabilidadeStatusSolicitacao() {
    const s = this.selectors.portabilidade;

    const itemPortabilidade = findMenuItemByText(s.menuPortabilidadeTexto);
    if (!itemPortabilidade) return { success: false, error: `item de menu "${s.menuPortabilidadeTexto}" não encontrado` };
    const itemAcompanhamento = await hoverUntilMenuItemAppears(itemPortabilidade, s.menuAcompanhamentoTexto);
    if (!itemAcompanhamento) return { success: false, error: `item de menu "${s.menuAcompanhamentoTexto}" não encontrado (depois de abrir "${s.menuPortabilidadeTexto}")` };

    const itemStatus = await hoverUntilMenuItemAppears(itemAcompanhamento, s.menuStatusSolicitacaoTexto);
    if (!itemStatus) return { success: false, error: `item de menu "${s.menuStatusSolicitacaoTexto}" não encontrado (depois de abrir "${s.menuAcompanhamentoTexto}")` };

    fireMouseEvent(itemStatus, 'click');
    itemStatus.click();
    return { success: true };
  }

  /** true se a tela atual é o formulário de pesquisa de Status da Solicitação. */
  isPortabilidadeForm() {
    const select = queryFirst(this.selectors.portabilidade.tipoConsultaSelect);
    if (!select) return false;
    const marca = this.selectors.portabilidade.tipoConsultaMarcaFormulario.toLowerCase();
    return Array.from(select.options).some((o) => (o.textContent || '').trim().toLowerCase().includes(marca));
  }

  confirmPortabilidadeCnpjSelected() {
    const select = queryFirst(this.selectors.portabilidade.tipoConsultaSelect);
    if (!select) return false;
    const selected = select.options[select.selectedIndex];
    return Boolean(
      selected && selected.textContent.trim().toLowerCase() === this.selectors.portabilidade.tipoConsultaCnpjLabel.toLowerCase()
    );
  }

  selectPortabilidadeCnpj() {
    const select = queryFirst(this.selectors.portabilidade.tipoConsultaSelect);
    if (!select) return { success: false, error: 'seletor "Tipo da Consulta" não encontrado' };
    const option = Array.from(select.options).find(
      (o) => o.textContent.trim().toLowerCase() === this.selectors.portabilidade.tipoConsultaCnpjLabel.toLowerCase()
    );
    if (!option) return { success: false, error: 'opção "CNPJ" não encontrada em "Tipo da Consulta"' };
    select.value = option.value;
    select.dispatchEvent(new Event('change', { bubbles: true }));
    return { success: this.confirmPortabilidadeCnpjSelected() };
  }

  /** Garante "CNPJ" selecionado, digita o CNPJ e clica Pesquisar (a página vai recarregar). */
  submitPortabilidadeCnpjQuery(cnpj) {
    let marcado = this.confirmPortabilidadeCnpjSelected();
    for (let tentativa = 1; tentativa <= 2 && !marcado; tentativa++) {
      const sel = this.selectPortabilidadeCnpj();
      if (!sel.success) return sel;
      marcado = this.confirmPortabilidadeCnpjSelected();
    }
    if (!marcado) return { success: false, error: 'não consegui marcar "CNPJ" em Tipo da Consulta' };

    const input = queryFirst(this.selectors.portabilidade.campoValor);
    if (!input) return { success: false, error: 'campo "Valor" não encontrado' };
    const valorLimpo = String(cnpj).replace(/\D/g, '');
    setNativeValue(input, valorLimpo);
    if (input.value !== valorLimpo) {
      return { success: false, error: `campo "Valor" não ficou com o valor certo — ficou "${input.value}"` };
    }

    const btn = findPesquisarButton(this.selectors.portabilidade.botaoPesquisarTexto);
    if (!btn) return { success: false, error: 'botão "Pesquisar" não encontrado' };
    btn.click();
    return { success: true };
  }

  /** Acha a tabela de resultados: tem coluna CNPJ e coluna Data Solicitação ao mesmo tempo. */
  findPortabilidadeResultsTable() {
    const s = this.selectors.portabilidade;
    const tabelas = document.querySelectorAll('table');
    for (const tabela of tabelas) {
      const headerRow = tabela.rows[0];
      if (!headerRow || !headerRow.cells || headerRow.cells.length === 0) continue;
      const textos = Array.from(headerRow.cells).map((c) => c.textContent.trim().toLowerCase());
      const temCnpj = textos.some((t) => t.includes(s.colunaCnpjTexto));
      const temData = textos.some((t) => t.includes(s.colunaDataSolicitacaoTexto));
      if (temCnpj && temData) return tabela;
    }
    return null;
  }

  /**
   * Seleciona uma linha com a Data Solicitação mais recente e clica
   * "detalhar". Se várias bolinhas empatam na data mais recente, `indice`
   * escolhe qual delas (0 = a de cima). Devolve `empatadas` (quantas
   * bolinhas têm essa mesma data) pro service-worker decidir se testa a
   * próxima.
   */
  selectMostRecentPortabilidadeResult(indice = 0) {
    const s = this.selectors.portabilidade;
    const tabela = this.findPortabilidadeResultsTable();
    if (!tabela) return { success: false, error: 'tabela de resultados da portabilidade não encontrada' };

    const headerRow = tabela.rows[0];
    const textos = Array.from(headerRow.cells).map((c) => c.textContent.trim().toLowerCase());
    const idxData = textos.findIndex((t) => t.includes(s.colunaDataSolicitacaoTexto));

    function parseDataBr(str) {
      const m = /(\d{2})\/(\d{2})\/(\d{4})/.exec(str || '');
      if (!m) return 0;
      return new Date(`${m[3]}-${m[2]}-${m[1]}T00:00:00`).getTime();
    }

    let melhorData = -1;
    let melhores = [];
    for (let i = 1; i < tabela.rows.length; i++) {
      const linha = tabela.rows[i];
      const radio = linha.querySelector('input[type="radio"]');
      if (!radio) continue;
      const dataTexto = idxData >= 0 ? (linha.cells[idxData]?.textContent || '') : '';
      const data = parseDataBr(dataTexto);
      if (data > melhorData) {
        melhorData = data;
        melhores = [linha];
      } else if (data === melhorData) {
        melhores.push(linha);
      }
    }
    if (melhores.length === 0) return { success: false, error: 'nenhuma linha com seleção (bolinha) encontrada no resultado' };
    const melhorLinha = melhores[Math.min(indice, melhores.length - 1)];

    const radio = melhorLinha.querySelector('input[type="radio"]');
    radio.checked = true;
    radio.dispatchEvent(new Event('change', { bubbles: true }));
    radio.dispatchEvent(new Event('click', { bubbles: true }));

    const botaoDetalhar = findDetalharButton(s.botaoDetalharTexto);
    if (!botaoDetalhar) return { success: false, error: 'botão "detalhar" não encontrado' };
    botaoDetalhar.click();
    return { success: true, empatadas: melhores.length };
  }

  /** Procura um rótulo visível (ex: "Status") e devolve o texto do elemento/célula seguinte (o valor). */
  findLabelValue(rotulo) {
    const alvo = normalizarRotulo(rotulo);
    const candidatos = document.querySelectorAll('td, th, span, label');
    for (const cel of candidatos) {
      const texto = normalizarRotulo(cel.textContent);
      if (texto !== alvo) continue;

      const linha = cel.closest('tr');
      if (linha && linha.cells) {
        const celulas = Array.from(linha.cells);
        const idx = celulas.indexOf(cel.closest('td') || cel);
        if (idx >= 0 && celulas[idx + 1] && celulas[idx + 1].textContent.trim()) {
          return celulas[idx + 1].textContent.trim();
        }
      }
      if (cel.nextElementSibling && cel.nextElementSibling.textContent.trim()) {
        return cel.nextElementSibling.textContent.trim();
      }
    }
    return '';
  }

  /** true se a tela atual é a de detalhe da solicitação (tem o rótulo de status visível). */
  isPortabilidadeDetailPage() {
    const s = this.selectors.portabilidade;
    return Boolean(
      this.findTableColumnValue(s.rotuloStatusPrincipal) ||
        this.findTableColumnValue(s.rotuloStatusAlternativo) ||
        // Detalhe em que nenhum número tem status ainda (vira FALHA no backend).
        this.findBilhetesAgrupadoresRows().length > 0
    );
  }

  /**
   * Lê o valor de uma COLUNA de tabela pelo texto do cabeçalho (ex: "Status"
   * na tabela "Bilhetes Agrupadores" — cabeçalho numa linha, valor na linha
   * de dados abaixo). Diferente de findLabelValue, que é pra rótulo e valor
   * lado a lado na MESMA linha (ex: "CNPJ | 54.087...").
   */
  findTableColumnValue(rotuloCabecalho) {
    const alvo = normalizarRotulo(rotuloCabecalho);
    const tabelas = document.querySelectorAll('table');
    for (const tabela of tabelas) {
      const headerRow = tabela.rows[0];
      if (!headerRow || !headerRow.cells) continue;
      const idx = Array.from(headerRow.cells).findIndex((c) => normalizarRotulo(c.textContent) === alvo);
      if (idx < 0) continue;
      for (let i = 1; i < tabela.rows.length; i++) {
        const texto = (tabela.rows[i].cells[idx]?.textContent || '').trim();
        if (texto) return texto;
      }
    }
    return '';
  }

  /** Todos os valores (inclusive "-") numa coluna "Motivo Recusa" de qualquer tabela da página, um por linha de Bilhete. */
  findMotivosRecusa() {
    const tabelas = document.querySelectorAll('table');
    for (const tabela of tabelas) {
      const headerRow = tabela.rows[0];
      if (!headerRow || !headerRow.cells) continue;
      const textos = Array.from(headerRow.cells).map((c) => c.textContent.trim().toLowerCase());
      const idx = textos.findIndex((t) => t.includes('motivo') && t.includes('recusa'));
      if (idx < 0) continue;
      const motivos = [];
      for (let i = 1; i < tabela.rows.length; i++) {
        const texto = (tabela.rows[i].cells[idx]?.textContent || '').trim();
        if (texto) motivos.push(texto);
      }
      if (motivos.length > 0) return motivos;
    }
    return [];
  }

  /**
   * Lê TODAS as linhas da tabela "Bilhetes Agrupadores" (uma por número),
   * de cima pra baixo. Por linha: o STATUS da coluna à direita de
   * "Quantidade de bilhete" (não o "Status do bilhete" ao lado do número
   * temporário), "Autorizado pela EA", "Motivo Recusa" e "Validação
   * Cadastral até". Linha SEM status também entra (status '') — o backend
   * grava FALHA nesses casos.
   */
  findBilhetesAgrupadoresRows() {
    const tabelas = document.querySelectorAll('table');
    for (const tabela of tabelas) {
      const headerRow = tabela.rows[0];
      if (!headerRow || !headerRow.cells) continue;
      const textos = Array.from(headerRow.cells).map((c) => normalizarRotulo(c.textContent));
      const semAcento = textos.map((t) => t.normalize('NFD').replace(/[\u0300-\u036f]/g, ''));
      const idxOperadora = textos.indexOf('operadora');
      const idxQuantidade = semAcento.findIndex((t) => t.includes('quantidade') && t.includes('bilhete'));
      // "Status" logo depois de "Quantidade de bilhete"; sem essa coluna, o
      // primeiro cabeçalho que é exatamente "Status".
      let idxStatus = idxQuantidade >= 0 ? textos.findIndex((t, i) => i > idxQuantidade && t === 'status') : -1;
      if (idxStatus < 0) idxStatus = textos.indexOf('status');
      const idxEa = semAcento.findIndex((t) => t.includes('autorizado') && /\bea\b/.test(t));
      const idxMotivo = semAcento.findIndex((t) => t.includes('motivo') && t.includes('recusa'));
      const idxValidacao = semAcento.findIndex((t) => t.includes('validacao cadastral'));
      if (idxOperadora < 0 || idxStatus < 0) continue;

      const celula = (cells, idx) => (idx >= 0 ? (cells[idx]?.textContent || '').trim() : '');
      const linhas = [];
      for (let i = 1; i < tabela.rows.length; i++) {
        const cells = tabela.rows[i].cells;
        // Pula linhas vazias/decorativas (sem operadora nem status).
        if (!celula(cells, idxOperadora) && !celula(cells, idxStatus)) continue;
        linhas.push({
          quantidade: parseInt(celula(cells, idxQuantidade), 10) || 0,
          status: celula(cells, idxStatus),
          autorizadoEa: celula(cells, idxEa),
          motivoRecusa: celula(cells, idxMotivo),
          validacaoCadastralAte: celula(cells, idxValidacao),
        });
      }
      if (linhas.length > 0) return linhas;
    }
    return [];
  }

  /**
   * Tabela de NÚMEROS (uma linha por "Número a portar"): é onde ficam o
   * "Autorizado pela EA" e o "Motivo Recusa" de cada número. Confirmado
   * em 21/10/2026: colunas Número a portar | Bilhete | Número Temporário |
   * Status do Bilhete | Autorização Doadora | Autorizado pela EA | Motivo
   * Recusa | Status da Linha | Motivo da Falha.
   */
  findNumerosRows() {
    const semAcento = (t) => normalizarRotulo(t).normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    for (const tabela of document.querySelectorAll('table')) {
      // O cabeçalho pode não ser a 1ª linha (às vezes há uma linha de título antes).
      let inicio = -1;
      let textos = [];
      for (let h = 0; h < Math.min(3, tabela.rows.length); h++) {
        const t = Array.from(tabela.rows[h].cells || []).map((c) => semAcento(c.textContent));
        if (t.some((x) => x.includes('numero a portar'))) {
          inicio = h;
          textos = t;
          break;
        }
      }
      if (inicio < 0) continue;
      const idxNumero = textos.findIndex((t) => t.includes('numero a portar'));
      const idxEa = textos.findIndex((t) => t.includes('autorizado') && /\bea\b/.test(t));
      const idxMotivo = textos.findIndex((t) => t.includes('motivo') && t.includes('recusa'));
      const celula = (cells, idx) => (idx >= 0 ? (cells[idx]?.textContent || '').trim() : '');
      const linhas = [];
      for (let i = inicio + 1; i < tabela.rows.length; i++) {
        const cells = tabela.rows[i].cells;
        const numero = celula(cells, idxNumero);
        if (!/\d{6,}/.test(numero)) continue;
        linhas.push({ numero, autorizadoEa: celula(cells, idxEa), motivoRecusa: celula(cells, idxMotivo) });
      }
      if (linhas.length > 0) return linhas;
    }
    return [];
  }

  /**
   * Uma linha por NÚMERO, de cima pra baixo: status do agrupador ao qual o
   * número pertence (coluna à direita de "Quantidade de bilhete" — cada
   * agrupador cobre os próximos N números, N = quantidade) + EA e motivo
   * do próprio número. Sem tabela de números, devolve os agrupadores.
   */
  montarLinhasPorNumero(agrupadores, numeros) {
    if (numeros.length === 0) return agrupadores;
    let idxAgrupador = 0;
    let restantes = agrupadores[0] ? agrupadores[0].quantidade || Infinity : 0;
    return numeros.map((n) => {
      while (restantes <= 0 && idxAgrupador < agrupadores.length - 1) {
        idxAgrupador++;
        restantes = agrupadores[idxAgrupador].quantidade || Infinity;
      }
      restantes--;
      const ag = agrupadores[idxAgrupador] || {};
      return {
        numero: n.numero,
        status: ag.status || '',
        autorizadoEa: n.autorizadoEa,
        motivoRecusa: n.motivoRecusa,
        validacaoCadastralAte: ag.validacaoCadastralAte || '',
      };
    });
  }

  extractPortabilidadeData() {
    const s = this.selectors.portabilidade;
    const agrupadoresTabela = this.findBilhetesAgrupadoresRows();
    const agrupadores = this.montarLinhasPorNumero(agrupadoresTabela, this.findNumerosRows());
    const motivosRecusa = this.findMotivosRecusa();
    // "Status" (coluna da tabela Bilhetes Agrupadores) é o valor correto
    // pra PORTADO/Conflito/Falha. "Status Sol. Port-In" é só o estado geral
    // da solicitação (ex: "Aguardando Portabilidade") — usado só como
    // reserva caso a tabela de Bilhetes Agrupadores não exista na tela.
    const status =
      (agrupadoresTabela[0] && agrupadoresTabela[0].status) ||
      this.findTableColumnValue(s.rotuloStatusPrincipal) ||
      this.findTableColumnValue(s.rotuloStatusAlternativo);
    return {
      status,
      motivoRecusa: motivosRecusa.find((m) => m !== '-') || '',
      agrupadores,
      motivosRecusa,
    };
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { P2BAutomation };
}
