/**
 * content.js
 * Ponte entre o background service worker e o módulo P2BAutomation.
 *
 * O Phoenix2Business usa frameset (a página de topo fica vazia, o
 * conteúdo real vive num frame interno) E recarrega a página inteira a
 * cada navegação/pesquisa. Isso quer dizer que este script roda do ZERO
 * a cada carregamento — ele não tenta "esperar o resultado", só reporta
 * o estado atual da página assim que carrega e expõe comandos curtos que
 * o background chama um de cada vez.
 */

(async function init() {
  const automation = new P2BAutomation(P2B_SELECTORS);

  const isRealFrame = await waitUntilP2BFrame(automation);
  if (!isRealFrame) return; // este frame não é o conteúdo do P2B; não faz nada

  // Assim que confirma que é o frame certo, já avisa o background do
  // estado desta página (isso acontece de novo, automaticamente, a cada
  // recarregamento — é assim que o background sabe que uma navegação
  // terminou e qual foi o resultado).
  avisarBackground({ type: 'P2B_STATE', payload: estadoSeguro(automation), url: window.location.href });

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // 1.5.2: um erro dentro de um comando não pode virar "erro da extensão"
    // nem deixar o background esperando: responde com { error } e segue.
    try {
      return tratarComando(automation, message, sendResponse)
    } catch (err) {
      // o retângulo do menu é usado como "achou/não achou": em erro, null.
      sendResponse(message.type === 'P2B_GET_MENU_ITEM_RECT' ? null : { success: false, error: err?.message || String(err) })
      return true
    }
  });
})();

// 1.5.2: avisar o background nunca pode quebrar. Quando a extensão é
// atualizada/recarregada e a aba não, ou o background ainda está
// acordando, o sendMessage dava "Receiving end does not exist" /
// "Extension context invalidated" no painel de erros da extensão.
function avisarBackground(msg) {
  try {
    if (!chrome.runtime?.id) return // extensão foi atualizada: esta aba precisa de F5
    const r = chrome.runtime.sendMessage(msg)
    if (r && typeof r.catch === 'function') r.catch(() => {})
  } catch {
    /* sem background agora: o alarme de 20s procura a aba de novo */
  }
}

function estadoSeguro(automation) {
  try {
    return automation.detectPageState()
  } catch (err) {
    return { kind: 'unknown', message: err?.message || String(err) }
  }
}

function tratarComando(automation, message, sendResponse) {
    switch (message.type) {
      case 'P2B_GET_STATE':
        sendResponse(estadoSeguro(automation));
        return true;
      case 'P2B_OPEN_CONTROLE_FATURA':
        sendResponse(automation.openInvoiceControl());
        return true;
      case 'P2B_SELECT_CODIGO_CLIENTE':
        sendResponse(automation.selectCustomerCode());
        return true;
      case 'P2B_SUBMIT_QUERY':
        sendResponse(automation.submitQuery((message.payload || {}).custCode));
        return true;
      case 'P2B_SELECT_CNPJ':
        sendResponse(automation.selectCnpjSearch())
        return true;
      case 'P2B_SUBMIT_CNPJ_QUERY':
        sendResponse(automation.submitCnpjQuery((message.payload || {}).cnpj))
        return true;
      case 'P2B_OPEN_PORTABILIDADE_STATUS':
        automation.openPortabilidadeStatusSolicitacao()
          .then(sendResponse)
          .catch((err) => sendResponse({ success: false, error: err?.message || String(err) }));
        return true;
      case 'P2B_SELECT_PORTABILIDADE_CNPJ':
        sendResponse(automation.selectPortabilidadeCnpj());
        return true;
      case 'P2B_SUBMIT_PORTABILIDADE_CNPJ_QUERY':
        sendResponse(automation.submitPortabilidadeCnpjQuery((message.payload || {}).cnpj));
        return true;
      case 'P2B_SELECT_PORTABILIDADE_RESULT':
        sendResponse(automation.selectMostRecentPortabilidadeResult((message.payload || {}).indice || 0));
        return true;
      case 'P2B_GET_MENU_ITEM_RECT':
        sendResponse(automation.getMenuItemRect((message.payload || {}).texto));
        return true;
      default:
        return false;
    }
}

function waitUntilP2BFrame(automation, { timeout = 8000, interval = 300 } = {}) {
  return new Promise((resolve) => {
    const start = Date.now();
    const check = () => {
      // '.conteiner' é um wrapper genérico que pode existir no DOM antes do
      // conteúdo real (tabela de resultados etc) terminar de carregar numa
      // página sem AJAX como essa — por isso também espera
      // document.readyState === 'complete' (página inteira, não só o DOM
      // inicial), evitando reportar o estado antigo/vazio antes da hora.
      if (automation.isP2BFrame() && document.readyState === 'complete') return resolve(true);
      if (Date.now() - start > timeout) return resolve(false);
      setTimeout(check, interval);
    };
    check();
  });
}
