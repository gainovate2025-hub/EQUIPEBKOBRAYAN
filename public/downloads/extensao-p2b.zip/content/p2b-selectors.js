/**
 * p2b-selectors.js
 * -----------------------------------------------------------------------
 * ÚNICO lugar do projeto onde ficam os seletores de elementos do P2B
 * (Phoenix2Business). Nada de seletores espalhados em outros arquivos —
 * se o P2B mudar a interface, ajuste apenas aqui.
 *
 * Estes valores foram capturados AO VIVO em 28/08/2026, navegando de
 * verdade na tela de "Consultas > Controle de Fatura" (não foram
 * inventados). O sistema é antigo, baseado em frames + telas geradas por
 * servlet — por isso vários seletores dependem de texto visível em vez de
 * IDs (o menu, por exemplo, é uma biblioteca DHTML antiga cujos IDs mudam
 * a cada carregamento de página).
 * -----------------------------------------------------------------------
 */

const P2B_SELECTORS = {
  // Confirma que o frame atual é o frame de conteúdo do Phoenix2Business
  // (o app usa frameset: o frame externo fica vazio, tudo relevante mora
  // no frame interno). ".conteiner" é a tabela-shell que envolve TODA
  // página interna do sistema (menu, formulário, resultado e até a tela
  // de erro) — por isso é a marca mais confiável, ao contrário de
  // elementos que só existem em algumas telas (ex: o formulário some na
  // tela de erro).
  markerElements: ['.conteiner'],

  // Endereço da tela "Consultas > Controle de Fatura". O menu do P2B é uma
  // biblioteca DHTML antiga (abre via hover, não de forma confiável com
  // clique simulado) — em vez de tentar simular esse clique, a automação
  // navega direto para este endereço, que é exatamente para onde o menu
  // leva (capturado ao vivo navegando pelo menu de verdade em 28/08/2026).
  // Se o P2B mudar de menu/URL no futuro, atualize este valor.
  controleFaturaUrl:
    'https://phoenix2businesspcs.timbrasil.com.br/phoenix2Business/servlet/phoenix2Business.apresentacao.ServletPhoenix2Business?servico=processarMenu&indiceFuncionalidade=10',

  // Select do tipo de pesquisa (CNPJ / Identificador do Cliente / Telefone / Código do Cliente)
  tipoPesquisaSelect: ['select[name="tipoConsulta"]'],
  tipoPesquisaCodigoClienteValue: '5',
  tipoPesquisaCodigoClienteLabel: 'Código do Cliente',
  // Modo "CNPJ -> CustCode" (28/09/2026): mesmo select, opção "CNPJ" — é
  // inclusive o valor padrão do formulário (ver observação abaixo), então
  // normalmente nem precisa selecionar nada. Não capturamos o "value" real
  // dessa opção ao vivo, então o código casa pelo texto visível (mesmo
  // jeito que já é a reserva pra Código do Cliente).
  tipoPesquisaCnpjValue: null,
  tipoPesquisaCnpjLabel: 'CNPJ',

  // Campo de entrada do CUST CODE
  campoCustCode: ['input[name="valor"]'],

  // Botão pesquisar (é uma <input type="image">, não um <button>)
  botaoPesquisar: ['#bt-pesquisar'],

  // Observação: não há mais seletor de "nova consulta"/"voltar" — em vez
  // de clicar nesses botões (que variam conforme a tela), a automação
  // sempre navega direto para `controleFaturaUrl` quando precisa voltar
  // ao formulário. O formulário reseta o tipo de pesquisa para CNPJ a
  // cada vez, por isso é preciso reselecionar "Código do Cliente" sempre.

  // Célula que exibe a mensagem de erro / não encontrado / sem fatura
  mensagemErro: ['td.erro'],
  textoNaoEncontrado: 'não encontrado',
  textoSemFatura: 'não possui faturas em aberto',

  // Tabela de resultado: identificada pelo cabeçalho "CustCode" (classe
  // "relatorio" nas células <th>), não por um id fixo — o app não usa ids
  // estáveis nessa tabela.
  tabelaResultadoHeaderText: 'CustCode',
  tabelaResultadoHeaderClass: 'relatorio',

  // Mapeia nomes de coluna (como aparecem no cabeçalho da tabela) para os
  // campos internos usados pela automação.
  colunasTabelaResultado: {
    telefone: ['telefones', 'telefone'],
    dataFatura: ['vencimento'],
    valorFatura: ['valor r$', 'valor'],
    numeroFatura: ['n° fatura', 'nº fatura', 'no fatura', 'numero fatura', 'número da fatura'],
  },

  // CNPJ do cliente (tabela separada, "Dados do Cliente")
  campoCnpj: ['table.roundForm td.frm3Col'],

  // Rótulo da seção acima da tabela de resultado (ex: "Faturas em Aberto")
  // usado como texto de status — é o próprio rótulo que o P2B exibe,
  // então não é um dado inventado.
  seletorStatusLabel: ['td.texto12'],

  // Modo "Portabilidade" (07/10/2026): Portabilidade > Acompanhamento >
  // Status da Solicitação. AO CONTRÁRIO do Controle de Fatura, ainda não
  // temos a URL fixa dessa tela capturada ao vivo (não foi possível
  // extrair pelo DevTools) — por isso a navegação simula os cliques reais
  // no menu DHTML (hover + clique, igual um usuário faria) em vez de ir
  // direto num endereço. Também não temos ids reais dos campos/tabelas
  // dessa tela: tudo abaixo foi montado a partir de prints da tela real,
  // casando por TEXTO VISÍVEL (rótulo de coluna, texto de botão) em vez de
  // id/classe — mesmo princípio já usado pros elementos sem id estável
  // acima. Se a navegação pelo menu ou algum seletor por texto falhar,
  // isso aparece nos logs da automação (visíveis no painel, sem precisar
  // de DevTools) — e dá pra ajustar aqui depois.
  portabilidade: {
    menuPortabilidadeTexto: 'Portabilidade',
    menuAcompanhamentoTexto: 'Acompanhamento',
    // Confirmado ao vivo em 07/10/2026: o texto real do item é "Status
    // Solicitações" (sem "da", no plural) — diferente do que a gente
    // imaginou de início ("Status da Solicitação").
    menuStatusSolicitacaoTexto: 'Status Solicitações',

    tipoConsultaSelect: ['select[name="tipoConsulta"]', 'select[name="tipoDaConsulta"]'],
    // Texto de uma opção que só existe nesse formulário (não existe no de
    // Controle de Fatura) — usado só pra CONFIRMAR que achamos o select
    // certo antes de mexer nele.
    tipoConsultaMarcaFormulario: 'a ser portado',
    tipoConsultaCnpjLabel: 'CNPJ',

    campoValor: ['input[name="valor"]'],
    botaoPesquisarTexto: 'pesquisar',

    // Tabela de resultado da pesquisa: identificada por TER ao mesmo tempo
    // uma coluna "CNPJ" e uma coluna "Data Solicitação" no cabeçalho — mais
    // confiável que confiar só em "CNPJ" (que também aparece em outras
    // tabelas da tela de detalhe).
    colunaCnpjTexto: 'cnpj',
    colunaDataSolicitacaoTexto: 'data solicita',
    botaoDetalharTexto: 'detalhar',

    // Tela de detalhe: lida por rótulo visível, não por id.
    // "Status" sozinho (o campo azul da seção "Bilhetes Agrupadores") é o
    // que se olha de verdade pra decidir PORTADO/Conflito/Falha/Cancelado
    // — rótulos mais longos tipo "Status Sol. Port-In" entram só como
    // alternativa caso o primeiro não seja encontrado.
    rotuloStatusPrincipal: 'Status',
    rotuloStatusAlternativo: 'Status Sol. Port-In',
    rotuloMotivoRecusa: 'Motivo Recusa',
  },
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { P2B_SELECTORS };
}
