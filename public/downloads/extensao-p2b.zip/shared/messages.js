/**
 * Shared message contract between backend <-> extension background <-> content script.
 * Kept in one place so the wire format never drifts between the three layers.
 * This file is plain JS (no bundler in the extension), loaded via <script> in
 * background/service-worker context (importScripts) and via manifest content_scripts.
 */

// backend -> extension (background) over the raw WebSocket (/ext)
const ServerToExtension = {
  PING: 'PING',
  RUN_SETUP: 'RUN_SETUP', // navigate Consultas -> Controle de Fatura -> Código do Cliente
  RUN_QUERY: 'RUN_QUERY', // { custCode } run one full query cycle
  GET_STATUS: 'GET_STATUS',
};

// extension (background) -> backend over the raw WebSocket (/ext)
const ExtensionToServer = {
  HELLO: 'HELLO', // { tabId, url } sent on connect
  PONG: 'PONG',
  STATUS: 'STATUS', // { p2bConnected, currentUrl }
  STEP_UPDATE: 'STEP_UPDATE', // { step, action } for live monitor panel
  SETUP_RESULT: 'SETUP_RESULT', // { success, error }
  QUERY_RESULT: 'QUERY_RESULT', // { custCode, success, notFound, data, error }
  LOG: 'LOG', // { level, message }
};

// background -> content script (chrome.tabs.sendMessage) and back
const BackgroundToContent = {
  RUN_SETUP: 'P2B_RUN_SETUP',
  RUN_QUERY: 'P2B_RUN_QUERY',
  PING: 'P2B_PING',
};

const ContentToBackground = {
  SETUP_RESULT: 'P2B_SETUP_RESULT',
  QUERY_RESULT: 'P2B_QUERY_RESULT',
  STEP_UPDATE: 'P2B_STEP_UPDATE',
  PONG: 'P2B_PONG',
};

const STEPS = {
  IDLE: 'IDLE',
  OPENING_CONSULTAS: 'CONSULTAS',
  OPENING_CONTROLE_FATURA: 'CONTROLE_FATURA',
  SELECTING_CODIGO_CLIENTE: 'CODIGO_CLIENTE',
  ENTERING_CUSTCODE: 'ENTERING_CUSTCODE',
  SEARCHING: 'PESQUISANDO',
  WAITING_RESULT: 'AGUARDANDO_RESULTADO',
  EXTRACTING: 'EXTRAINDO_DADOS',
  RETURNING: 'RETORNANDO',
  DONE: 'CONCLUIDO',
  ERROR: 'ERRO',
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { ServerToExtension, ExtensionToServer, BackgroundToContent, ContentToBackground, STEPS };
}
