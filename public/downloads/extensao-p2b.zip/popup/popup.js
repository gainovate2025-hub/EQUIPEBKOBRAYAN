function setDot(id, textId, ok, onText, offText) {
  const dot = document.getElementById(id);
  const txt = document.getElementById(textId);
  dot.className = `dot ${ok ? 'on' : 'off'}`;
  txt.textContent = ok ? onText : offText;
}

function showError(text) {
  const errorEl = document.getElementById('pair-error');
  if (text) {
    errorEl.textContent = text;
    errorEl.style.display = 'block';
  } else {
    errorEl.style.display = 'none';
  }
}

function render(status) {
  const pairSection = document.getElementById('pair-section');
  const statusSection = document.getElementById('status-section');

  if (status.paired) {
    pairSection.style.display = 'none';
    statusSection.style.display = 'block';
    setDot('dot-backend', 'txt-backend', status.backendConnected, 'Backend: conectado', 'Backend: desconectado');
    setDot('dot-p2b', 'txt-p2b', status.p2bConnected, 'P2B: conectado', 'P2B: aba não encontrada');
  } else {
    pairSection.style.display = 'block';
    statusSection.style.display = 'none';
  }
}

function refreshStatus() {
  chrome.runtime.sendMessage({ type: 'GET_POPUP_STATUS' }, (response) => {
    render(response || { backendConnected: false, paired: false, p2bConnected: false });
  });
}

document.getElementById('btn-pair').addEventListener('click', () => {
  const code = document.getElementById('code').value.trim();
  const btn = document.getElementById('btn-pair');
  showError(null);

  if (code.length !== 6) {
    showError('Digite o código de 6 dígitos.');
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Conectando...';

  chrome.runtime.sendMessage({ type: 'SET_PAIRING_CODE', code }, (response) => {
    btn.disabled = false;
    btn.textContent = 'Conectar';
    if (response && response.ok) {
      refreshStatus();
    } else {
      showError((response && response.error) || 'Não foi possível conectar. Tente de novo.');
    }
  });
});

document.getElementById('btn-forget').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'FORGET_PAIRING' }, () => {
    refreshStatus();
  });
});

refreshStatus();
